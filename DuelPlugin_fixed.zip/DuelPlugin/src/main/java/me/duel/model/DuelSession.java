package me.duel.model;

import org.bukkit.Location;
import org.bukkit.block.BlockState;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class DuelSession {

    public enum State { COUNTDOWN, FIGHTING, ENDED }

    private final UUID player1;
    private final UUID player2;
    private final Arena arena;
    private final String kitName;
    private final int maxRounds;

    private int winsPlayer1 = 0;
    private int winsPlayer2 = 0;
    private int currentRound = 1;

    private State state = State.COUNTDOWN;
    private long startTime;

    private ItemStack[] savedInventory1;
    private ItemStack[] savedInventory2;
    private ItemStack[] savedArmor1;
    private ItemStack[] savedArmor2;
    private Location savedLocation1;
    private Location savedLocation2;

    private final Map<Location, BlockState> changedBlocks = new LinkedHashMap<>();
    private final Set<UUID> spectators = new HashSet<>();

    public DuelSession(UUID player1, UUID player2, Arena arena, String kitName, int maxRounds) {
        this.player1 = player1;
        this.player2 = player2;
        this.arena = arena;
        this.kitName = kitName;
        this.maxRounds = maxRounds;
    }

    public void trackBlock(Location loc, BlockState original) {
        Location key = loc.clone();
        changedBlocks.putIfAbsent(key, original);
    }

    public Map<Location, BlockState> getChangedBlocks() { return changedBlocks; }

    public void recordWin(UUID winner) {
        if (winner.equals(player1)) winsPlayer1++;
        else winsPlayer2++;
        currentRound++;
    }

    public UUID getMatchWinner() {
        int needed = (maxRounds / 2) + 1;
        if (winsPlayer1 >= needed) return player1;
        if (winsPlayer2 >= needed) return player2;
        return null;
    }

    public boolean isMatchOver() {
        return getMatchWinner() != null || currentRound > maxRounds;
    }

    public void addSpectator(UUID uuid) { spectators.add(uuid); }
    public void removeSpectator(UUID uuid) { spectators.remove(uuid); }
    public Set<UUID> getSpectators() { return spectators; }
    public boolean isSpectator(UUID uuid) { return spectators.contains(uuid); }

    public UUID getPlayer1() { return player1; }
    public UUID getPlayer2() { return player2; }
    public Arena getArena() { return arena; }
    public String getKitName() { return kitName; }
    public int getMaxRounds() { return maxRounds; }
    public int getCurrentRound() { return currentRound; }
    public int getWinsPlayer1() { return winsPlayer1; }
    public int getWinsPlayer2() { return winsPlayer2; }
    public State getState() { return state; }
    public void setState(State state) { this.state = state; }
    public long getStartTime() { return startTime; }
    public void setStartTime(long startTime) { this.startTime = startTime; }

    public boolean isParticipant(UUID uuid) { return player1.equals(uuid) || player2.equals(uuid); }
    public UUID getOpponent(UUID uuid) { return player1.equals(uuid) ? player2 : player1; }

    public int getWinsForPlayer(UUID uuid) { return player1.equals(uuid) ? winsPlayer1 : winsPlayer2; }

    public ItemStack[] getSavedInventory1() { return savedInventory1; }
    public void setSavedInventory1(ItemStack[] i) { this.savedInventory1 = i; }
    public ItemStack[] getSavedInventory2() { return savedInventory2; }
    public void setSavedInventory2(ItemStack[] i) { this.savedInventory2 = i; }
    public ItemStack[] getSavedArmor1() { return savedArmor1; }
    public void setSavedArmor1(ItemStack[] a) { this.savedArmor1 = a; }
    public ItemStack[] getSavedArmor2() { return savedArmor2; }
    public void setSavedArmor2(ItemStack[] a) { this.savedArmor2 = a; }
    public Location getSavedLocation1() { return savedLocation1; }
    public void setSavedLocation1(Location l) { this.savedLocation1 = l; }
    public Location getSavedLocation2() { return savedLocation2; }
    public void setSavedLocation2(Location l) { this.savedLocation2 = l; }
}

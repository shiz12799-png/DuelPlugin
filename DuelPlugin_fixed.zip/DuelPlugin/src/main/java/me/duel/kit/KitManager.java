package me.duel.kit;

import me.duel.DuelPlugin;
import me.duel.model.DuelKit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.*;
import java.util.*;
import java.util.Base64;

public class KitManager {

    private final DuelPlugin plugin;
    private final Map<String, DuelKit> kits = new LinkedHashMap<>();
    private File file;
    private FileConfiguration config;

    public KitManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        kits.clear();
        file = new File(plugin.getDataFolder(), "kits.yml");
        if (!file.exists()) plugin.saveResource("kits.yml", false);
        config = YamlConfiguration.loadConfiguration(file);

        if (config.isConfigurationSection("kits")) {
            for (String key : config.getConfigurationSection("kits").getKeys(false)) {
                try {
                    String display = config.getString("kits." + key + ".display", key);
                    List<ItemStack> items = deserializeItems(config.getString("kits." + key + ".items", ""));
                    ItemStack[] armor = deserializeArmor(config.getString("kits." + key + ".armor", ""));
                    kits.put(key.toUpperCase(), new DuelKit(key.toUpperCase(), display, items, armor));
                } catch (Exception e) {
                    plugin.getLogger().warning("Failed to load kit: " + key);
                }
            }
        }
        plugin.getLogger().info("Loaded " + kits.size() + " kits.");
    }

    public void saveKit(DuelKit kit) {
        String path = "kits." + kit.getName();
        config.set(path + ".display", kit.getDisplay());
        config.set(path + ".items", serializeItems(kit.getItems()));
        config.set(path + ".armor", serializeArmor(kit.getArmor()));
        try { config.save(file); } catch (IOException e) { plugin.getLogger().warning("Could not save kits.yml"); }
        kits.put(kit.getName().toUpperCase(), kit);
    }

    public void deleteKit(String name) {
        kits.remove(name.toUpperCase());
        config.set("kits." + name, null);
        try { config.save(file); } catch (IOException e) { plugin.getLogger().warning("Could not save kits.yml"); }
    }

    public void giveKit(Player player, String kitName) {
        DuelKit kit = getKit(kitName);
        if (kit == null) return;
        player.getInventory().clear();
        player.getInventory().setContents(new ItemStack[36]);
        for (int i = 0; i < kit.getItems().size() && i < 36; i++) {
            player.getInventory().setItem(i, kit.getItems().get(i).clone());
        }
        ItemStack[] armor = kit.getArmor();
        if (armor != null && armor.length == 4) {
            player.getInventory().setHelmet(armor[0] != null ? armor[0].clone() : null);
            player.getInventory().setChestplate(armor[1] != null ? armor[1].clone() : null);
            player.getInventory().setLeggings(armor[2] != null ? armor[2].clone() : null);
            player.getInventory().setBoots(armor[3] != null ? armor[3].clone() : null);
        }
        player.updateInventory();
    }

    /** Create a kit from a player's current inventory+armor */
    public DuelKit createFromPlayer(String name, Player player) {
        List<ItemStack> items = new ArrayList<>();
        for (ItemStack item : player.getInventory().getStorageContents()) {
            if (item != null) items.add(item.clone());
        }
        ItemStack[] armor = new ItemStack[4];
        armor[0] = player.getInventory().getHelmet() != null ? player.getInventory().getHelmet().clone() : null;
        armor[1] = player.getInventory().getChestplate() != null ? player.getInventory().getChestplate().clone() : null;
        armor[2] = player.getInventory().getLeggings() != null ? player.getInventory().getLeggings().clone() : null;
        armor[3] = player.getInventory().getBoots() != null ? player.getInventory().getBoots().clone() : null;
        return new DuelKit(name.toUpperCase(), name, items, armor);
    }

    private String serializeItems(List<ItemStack> items) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            BukkitObjectOutputStream oos = new BukkitObjectOutputStream(bos);
            oos.writeInt(items.size());
            for (ItemStack item : items) oos.writeObject(item);
            oos.close();
            return Base64.getEncoder().encodeToString(bos.toByteArray());
        } catch (IOException e) { return ""; }
    }

    private List<ItemStack> deserializeItems(String data) {
        if (data == null || data.isEmpty()) return new ArrayList<>();
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(Base64.getDecoder().decode(data));
            BukkitObjectInputStream ois = new BukkitObjectInputStream(bis);
            int size = ois.readInt();
            List<ItemStack> items = new ArrayList<>();
            for (int i = 0; i < size; i++) items.add((ItemStack) ois.readObject());
            ois.close();
            return items;
        } catch (Exception e) { return new ArrayList<>(); }
    }

    private String serializeArmor(ItemStack[] armor) {
        if (armor == null) return "";
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            BukkitObjectOutputStream oos = new BukkitObjectOutputStream(bos);
            oos.writeInt(armor.length);
            for (ItemStack item : armor) oos.writeObject(item);
            oos.close();
            return Base64.getEncoder().encodeToString(bos.toByteArray());
        } catch (IOException e) { return ""; }
    }

    private ItemStack[] deserializeArmor(String data) {
        if (data == null || data.isEmpty()) return new ItemStack[4];
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(Base64.getDecoder().decode(data));
            BukkitObjectInputStream ois = new BukkitObjectInputStream(bis);
            int size = ois.readInt();
            ItemStack[] armor = new ItemStack[size];
            for (int i = 0; i < size; i++) armor[i] = (ItemStack) ois.readObject();
            ois.close();
            return armor;
        } catch (Exception e) { return new ItemStack[4]; }
    }

    public DuelKit getKit(String name) { return name == null ? null : kits.get(name.toUpperCase()); }
    public boolean exists(String name) { return name != null && kits.containsKey(name.toUpperCase()); }
    public Collection<DuelKit> getKits() { return kits.values(); }
}

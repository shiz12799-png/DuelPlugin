package me.duel.model;

import java.util.UUID;

public class QueueEntry {
    private final UUID playerUuid;
    private final String kitName;
    private final int rounds;
    private final int elo;

    public QueueEntry(UUID playerUuid, String kitName, int rounds, int elo) {
        this.playerUuid = playerUuid;
        this.kitName = kitName;
        this.rounds = rounds;
        this.elo = elo;
    }

    public UUID getPlayerUuid() { return playerUuid; }
    public String getKitName() { return kitName; }
    public int getRounds() { return rounds; }
    public int getElo() { return elo; }
}

package me.duel.manager;

import me.duel.DuelPlugin;
import me.duel.model.QueueEntry;
import me.duel.util.ChatUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class QueueManager {

    private final DuelPlugin plugin;
    // kit+rounds key → list of waiting players
    private final Map<String, List<QueueEntry>> queues = new HashMap<>();

    public QueueManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public void startTask() {
        int interval = plugin.getConfig().getInt("duel.queue-check-interval", 3);
        new BukkitRunnable() {
            @Override
            public void run() {
                processQueues();
            }
        }.runTaskTimer(plugin, 20L, interval * 20L);
    }

    private void processQueues() {
        int eloRange = plugin.getConfig().getInt("duel.queue-elo-range", 100);

        for (Map.Entry<String, List<QueueEntry>> entry : queues.entrySet()) {
            List<QueueEntry> list = entry.getValue();
            list.removeIf(e -> Bukkit.getPlayer(e.getPlayerUuid()) == null
                    || plugin.getDuelManager().isInDuel(e.getPlayerUuid()));

            if (list.size() < 2) continue;

            // Try to find a match within ELO range
            outer:
            for (int i = 0; i < list.size(); i++) {
                for (int j = i + 1; j < list.size(); j++) {
                    QueueEntry a = list.get(i);
                    QueueEntry b = list.get(j);
                    if (Math.abs(a.getElo() - b.getElo()) <= eloRange) {
                        list.remove(j);
                        list.remove(i);
                        Player pa = Bukkit.getPlayer(a.getPlayerUuid());
                        Player pb = Bukkit.getPlayer(b.getPlayerUuid());
                        if (pa != null && pb != null) {
                            pa.sendMessage(ChatUtil.color("&8[&6⚔ &eDuel&8] &aНайден противник: &e" + pb.getName()));
                            pb.sendMessage(ChatUtil.color("&8[&6⚔ &eDuel&8] &aНайден противник: &e" + pa.getName()));
                            plugin.getDuelManager().startDuel(pa, pb, a.getKitName(), a.getRounds());
                        }
                        break outer;
                    }
                }
            }
        }

        updateSigns();
    }

    public boolean joinQueue(Player player, String kitName, int rounds) {
        if (plugin.getDuelManager().isInDuel(player.getUniqueId())) return false;
        if (isInQueue(player.getUniqueId())) return false;

        String key = makeKey(kitName, rounds);
        queues.computeIfAbsent(key, k -> new ArrayList<>());

        var stats = plugin.getDatabaseManager().getStats(player.getUniqueId(), player.getName());
        queues.get(key).add(new QueueEntry(player.getUniqueId(), kitName, rounds, stats.getElo()));
        updateSigns();
        return true;
    }

    public boolean leaveQueue(Player player) {
        UUID uuid = player.getUniqueId();
        boolean removed = false;
        for (List<QueueEntry> list : queues.values()) {
            removed |= list.removeIf(e -> e.getPlayerUuid().equals(uuid));
        }
        if (removed) updateSigns();
        return removed;
    }

    public boolean isInQueue(UUID uuid) {
        return queues.values().stream().flatMap(List::stream)
                .anyMatch(e -> e.getPlayerUuid().equals(uuid));
    }

    public int getQueueSize(String kitName, int rounds) {
        List<QueueEntry> list = queues.get(makeKey(kitName, rounds));
        return list == null ? 0 : list.size();
    }

    private String makeKey(String kit, int rounds) {
        return (kit == null ? "DEFAULT" : kit.toUpperCase()) + ":" + rounds;
    }

    private void updateSigns() {
        plugin.getSignQueueManager().updateAllSigns();
    }
}

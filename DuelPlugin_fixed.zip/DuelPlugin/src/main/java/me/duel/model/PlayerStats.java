package me.duel.model;

import java.util.UUID;

public class PlayerStats {
    private final UUID uuid;
    private final String name;
    private int elo;
    private int wins;
    private int losses;
    private int draws;
    private int currentStreak;
    private int bestStreak;

    public PlayerStats(UUID uuid, String name, int elo, int wins, int losses, int draws, int currentStreak, int bestStreak) {
        this.uuid = uuid;
        this.name = name;
        this.elo = elo;
        this.wins = wins;
        this.losses = losses;
        this.draws = draws;
        this.currentStreak = currentStreak;
        this.bestStreak = bestStreak;
    }

    public double getWinRate() {
        int total = wins + losses;
        if (total == 0) return 0.0;
        return (double) wins / total * 100.0;
    }

    public UUID getUuid() { return uuid; }
    public String getName() { return name; }
    public int getElo() { return elo; }
    public void setElo(int elo) { this.elo = elo; }
    public int getWins() { return wins; }
    public void setWins(int wins) { this.wins = wins; }
    public int getLosses() { return losses; }
    public void setLosses(int losses) { this.losses = losses; }
    public int getDraws() { return draws; }
    public void setDraws(int draws) { this.draws = draws; }
    public int getCurrentStreak() { return currentStreak; }
    public void setCurrentStreak(int currentStreak) { this.currentStreak = currentStreak; }
    public int getBestStreak() { return bestStreak; }
    public void setBestStreak(int bestStreak) { this.bestStreak = bestStreak; }
}

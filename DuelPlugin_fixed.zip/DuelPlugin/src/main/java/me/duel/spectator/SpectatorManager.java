package me.duel.spectator;

import me.duel.DuelPlugin;
import me.duel.model.DuelSession;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.UUID;

public class SpectatorManager {

    private final DuelPlugin plugin;

    public SpectatorManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean addSpectator(Player spectator, Player target) {
        DuelSession session = plugin.getDuelManager().getSession(target.getUniqueId());
        if (session == null) return false;

        session.addSpectator(spectator.getUniqueId());
        spectator.setGameMode(GameMode.SPECTATOR);
        spectator.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0, false, false));
        spectator.teleport(target.getLocation());
        spectator.sendMessage(plugin.getConfig().getString("messages.prefix", "&8[&6⚔ &eDuel&8] &r")
                .replace("&", "§") + "§7Вы наблюдаете за §e" + target.getName() + "§7.");
        return true;
    }

    public void removeSpectator(Player spectator) {
        UUID uuid = spectator.getUniqueId();
        plugin.getDuelManager().getSessions().forEach(s -> s.removeSpectator(uuid));
        spectator.setGameMode(GameMode.SURVIVAL);
        spectator.removePotionEffect(PotionEffectType.INVISIBILITY);
        teleportToLobby(spectator);
        spectator.sendMessage(plugin.getConfig().getString("messages.prefix", "&8[&6⚔ &eDuel&8] &r")
                .replace("&", "§") + "§7Вы покинули наблюдение.");
    }

    public boolean isSpectating(UUID uuid) {
        return plugin.getDuelManager().getSessions().stream()
                .anyMatch(s -> s.isSpectator(uuid));
    }

    private void teleportToLobby(Player player) {
        var cfg = plugin.getConfig();
        String worldName = cfg.getString("duel.lobby-spawn.world", "world");
        World world = plugin.getServer().getWorld(worldName);
        if (world == null) return;
        player.teleport(new Location(world,
                cfg.getDouble("duel.lobby-spawn.x"),
                cfg.getDouble("duel.lobby-spawn.y"),
                cfg.getDouble("duel.lobby-spawn.z"),
                (float) cfg.getDouble("duel.lobby-spawn.yaw"),
                (float) cfg.getDouble("duel.lobby-spawn.pitch")));
    }
}

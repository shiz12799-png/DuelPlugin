package me.duel.model;

import org.bukkit.Location;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class DuelSession {

    public enum State { COUNTDOWN, FIGHTING, ENDED }

    private final UUID player1;
    private final UUID player2;
    private final String kitName;
    private final int totalRounds;
    private final Arena arena;

    private State state;
    private int roundsPlayer1;
    private int roundsPlayer2;
    private int currentRound;
    private long startTime;
    private int elapsedSeconds;

    // saved inventories
    private ItemStack[] inv1;
    private ItemStack[] inv2;
    private ItemStack[] armor1;
    private ItemStack[] armor2;
    private Location returnLoc1;
    private Location returnLoc2;

    // arena cleanup
    private final Map<Location, BlockData> changedBlocks = new HashMap<>();
    private final Set<UUID> spectators = new HashSet<>();

    public DuelSession(UUID player1, UUID player2, String kitName, int totalRounds, Arena arena) {
        this.player1 = player1;
        this.player2 = player2;
        this.kitName = kitName;
        this.totalRounds = totalRounds;
        this.arena = arena;
        this.state = State.COUNTDOWN;
        this.roundsPlayer1 = 0;
        this.roundsPlayer2 = 0;
        this.currentRound = 1;
        this.startTime = System.currentTimeMillis();
        this.elapsedSeconds = 0;
    }

    public boolean isPlayer(UUID uuid) {
        return player1.equals(uuid) || player2.equals(uuid);
    }

    public UUID getOpponent(UUID uuid) {
        return player1.equals(uuid) ? player2 : player1;
    }

    public int getWinsNeeded() {
        return (totalRounds / 2) + 1;
    }

    public boolean isMatchOver() {
        return roundsPlayer1 >= getWinsNeeded() || roundsPlayer2 >= getWinsNeeded();
    }

    public UUID getMatchWinner() {
        if (roundsPlayer1 > roundsPlayer2) return player1;
        if (roundsPlayer2 > roundsPlayer1) return player2;
        return null; // draw
    }

    public void recordBlockChange(Location loc, BlockData original) {
        changedBlocks.putIfAbsent(loc.clone(), original);
    }

    // ---- getters/setters ----
    public UUID getPlayer1() { return player1; }
    public UUID getPlayer2() { return player2; }
    public String getKitName() { return kitName; }
    public int getTotalRounds() { return totalRounds; }
    public Arena getArena() { return arena; }
    public State getState() { return state; }
    public void setState(State state) { this.state = state; }
    public int getRoundsPlayer1() { return roundsPlayer1; }
    public void setRoundsPlayer1(int r) { this.roundsPlayer1 = r; }
    public int getRoundsPlayer2() { return roundsPlayer2; }
    public void setRoundsPlayer2(int r) { this.roundsPlayer2 = r; }
    public int getCurrentRound() { return currentRound; }
    public void setCurrentRound(int r) { this.currentRound = r; }
    public long getStartTime() { return startTime; }
    public void setStartTime(long t) { this.startTime = t; }
    public int getElapsedSeconds() { return elapsedSeconds; }
    public void setElapsedSeconds(int s) { this.elapsedSeconds = s; }
    public ItemStack[] getInv1() { return inv1; }
    public void setInv1(ItemStack[] inv1) { this.inv1 = inv1; }
    public ItemStack[] getInv2() { return inv2; }
    public void setInv2(ItemStack[] inv2) { this.inv2 = inv2; }
    public ItemStack[] getArmor1() { return armor1; }
    public void setArmor1(ItemStack[] armor1) { this.armor1 = armor1; }
    public ItemStack[] getArmor2() { return armor2; }
    public void setArmor2(ItemStack[] armor2) { this.armor2 = armor2; }
    public Location getReturnLoc1() { return returnLoc1; }
    public void setReturnLoc1(Location l) { this.returnLoc1 = l; }
    public Location getReturnLoc2() { return returnLoc2; }
    public void setReturnLoc2(Location l) { this.returnLoc2 = l; }
    public Map<Location, BlockData> getChangedBlocks() { return changedBlocks; }
    public Set<UUID> getSpectators() { return spectators; }
}

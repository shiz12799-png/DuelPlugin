package me.duel.util;

import org.bukkit.ChatColor;

public final class C {
    private C() {}
    public static final String PREFIX = ChatColor.translateAlternateColorCodes('&', "&8[&6⚔ &eDuel&8] &r");
    public static String color(String s) { return ChatColor.translateAlternateColorCodes('&', s); }
    public static String msg(String s) { return PREFIX + color(s); }
}

package me.duel.command;

import me.duel.DuelPlugin;
import me.duel.util.ChatUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class DuelPluginCommand implements CommandExecutor {

    private final DuelPlugin plugin;

    public DuelPluginCommand(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("duel.admin")) {
            sender.sendMessage(ChatUtil.msg("&cНет прав."));
            return true;
        }

        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            plugin.reload();
            sender.sendMessage(ChatUtil.msg("&aПлагин перезагружен!"));
            sender.sendMessage(ChatUtil.msg("&7Арен: &e" + plugin.getArenaManager().getAll().size()
                    + " &7| Китов: &e" + plugin.getKitManager().getAll().size()));
        } else {
            sender.sendMessage(ChatUtil.msg("&eИспользование: /duelplugin reload"));
        }
        return true;
    }
}

package me.duel.manager;

import me.duel.DuelPlugin;
import me.duel.util.ChatUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;

public class SignQueueManager {

    private final DuelPlugin plugin;
    // Location string → [kitName, rounds]
    private final Map<String, SignData> signs = new HashMap<>();
    private File signFile;
    private FileConfiguration signConfig;

    public record SignData(String kitName, int rounds) {}

    public SignQueueManager(DuelPlugin plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        signs.clear();
        signFile = new File(plugin.getDataFolder(), "signs.yml");
        if (!signFile.exists()) {
            try { signFile.createNewFile(); } catch (IOException ignored) {}
        }
        signConfig = YamlConfiguration.loadConfiguration(signFile);
        ConfigurationSection section = signConfig.getConfigurationSection("signs");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            String kit = section.getString(key + ".kit");
            int rounds = section.getInt(key + ".rounds", 1);
            signs.put(key, new SignData(kit, rounds));
        }
    }

    public void reload() {
        load();
        updateAllSigns();
    }

    public void registerSign(Location loc, String kitName, int rounds) {
        String key = locKey(loc);
        signs.put(key, new SignData(kitName, rounds));
        saveSign(key, kitName, rounds);
        updateSign(loc, kitName, rounds);
    }

    public boolean removeSign(Location loc) {
        String key = locKey(loc);
        if (signs.remove(key) == null) return false;
        signConfig.set("signs." + key, null);
        save();
        return true;
    }

    public boolean isQueueSign(Location loc) {
        return signs.containsKey(locKey(loc));
    }

    public SignData getSignData(Location loc) {
        return signs.get(locKey(loc));
    }

    public void updateAllSigns() {
        for (Map.Entry<String, SignData> entry : signs.entrySet()) {
            Location loc = keyToLoc(entry.getKey());
            if (loc != null) updateSign(loc, entry.getValue().kitName(), entry.getValue().rounds());
        }
    }

    private void updateSign(Location loc, String kitName, int rounds) {
        Block block = loc.getBlock();
        if (!(block.getState() instanceof Sign sign)) return;

        int queueSize = plugin.getQueueManager().getQueueSize(kitName, rounds);
        String bo = rounds == 1 ? "БО1" : "БО" + rounds;
        String kit = kitName != null ? kitName : "DEFAULT";

        sign.setLine(0, ChatColor.GOLD + "" + ChatColor.BOLD + "⚔ DUEL QUEUE");
        sign.setLine(1, ChatColor.YELLOW + kit);
        sign.setLine(2, ChatColor.GRAY + "Раунды: " + ChatColor.WHITE + bo);
        sign.setLine(3, ChatColor.GREEN + "В очереди: " + ChatColor.WHITE + queueSize);
        sign.update();
    }

    private void saveSign(String key, String kitName, int rounds) {
        signConfig.set("signs." + key + ".kit", kitName);
        signConfig.set("signs." + key + ".rounds", rounds);
        save();
    }

    private void save() {
        try { signConfig.save(signFile); }
        catch (IOException e) { plugin.getLogger().log(Level.WARNING, "Failed to save signs", e); }
    }

    private String locKey(Location loc) {
        return loc.getWorld().getName() + "," + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ();
    }

    private Location keyToLoc(String key) {
        String[] parts = key.split(",");
        if (parts.length != 4) return null;
        World world = Bukkit.getWorld(parts[0]);
        if (world == null) return null;
        try {
            return new Location(world,
                    Integer.parseInt(parts[1]),
                    Integer.parseInt(parts[2]),
                    Integer.parseInt(parts[3]));
        } catch (NumberFormatException e) { return null; }
    }
}

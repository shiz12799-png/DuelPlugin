package me.duel.arena;

import me.duel.DuelPlugin;
import me.duel.model.Arena;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;

public class ArenaManager {

    private final DuelPlugin plugin;
    private final Map<String, Arena> arenas = new LinkedHashMap<>();
    private File arenaFile;
    private FileConfiguration arenaConfig;

    public ArenaManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        arenas.clear();
        arenaFile = new File(plugin.getDataFolder(), "arenas.yml");
        if (!arenaFile.exists()) plugin.saveResource("arenas.yml", false);
        arenaConfig = YamlConfiguration.loadConfiguration(arenaFile);

        ConfigurationSection section = arenaConfig.getConfigurationSection("arenas");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            Location spawn1 = loadLocation(section, key + ".spawn1");
            Location spawn2 = loadLocation(section, key + ".spawn2");
            arenas.put(key.toLowerCase(), new Arena(key, spawn1, spawn2));
        }
        plugin.getLogger().info("Loaded " + arenas.size() + " arenas.");
    }

    private void save() {
        try {
            arenaConfig.set("arenas", null);
            for (Arena arena : arenas.values()) {
                String base = "arenas." + arena.getName();
                if (arena.getSpawn1() != null) saveLocation(arenaConfig, base + ".spawn1", arena.getSpawn1());
                if (arena.getSpawn2() != null) saveLocation(arenaConfig, base + ".spawn2", arena.getSpawn2());
            }
            arenaConfig.save(arenaFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Failed to save arenas", e);
        }
    }

    public boolean createArena(String name) {
        if (arenas.containsKey(name.toLowerCase())) return false;
        arenas.put(name.toLowerCase(), new Arena(name, null, null));
        save();
        return true;
    }

    public boolean deleteArena(String name) {
        if (arenas.remove(name.toLowerCase()) == null) return false;
        save();
        return true;
    }

    public boolean setSpawn(String name, int num, Location loc) {
        Arena arena = arenas.get(name.toLowerCase());
        if (arena == null) return false;
        if (num == 1) arena.setSpawn1(loc);
        else arena.setSpawn2(loc);
        save();
        return true;
    }

    public Optional<Arena> getFreeArena() {
        return arenas.values().stream()
                .filter(a -> !a.isInUse() && a.isReady())
                .findFirst();
    }

    public Arena getArena(String name) { return arenas.get(name.toLowerCase()); }
    public Collection<Arena> getAll() { return arenas.values(); }

    private void saveLocation(FileConfiguration cfg, String path, Location loc) {
        cfg.set(path + ".world", loc.getWorld().getName());
        cfg.set(path + ".x", loc.getX());
        cfg.set(path + ".y", loc.getY());
        cfg.set(path + ".z", loc.getZ());
        cfg.set(path + ".yaw", (double) loc.getYaw());
        cfg.set(path + ".pitch", (double) loc.getPitch());
    }

    private Location loadLocation(ConfigurationSection section, String path) {
        if (!section.contains(path + ".world")) return null;
        String worldName = section.getString(path + ".world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        return new Location(world,
                section.getDouble(path + ".x"),
                section.getDouble(path + ".y"),
                section.getDouble(path + ".z"),
                (float) section.getDouble(path + ".yaw"),
                (float) section.getDouble(path + ".pitch"));
    }
}

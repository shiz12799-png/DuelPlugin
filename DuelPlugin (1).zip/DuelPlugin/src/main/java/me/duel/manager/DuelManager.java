package me.duel.manager;

import me.duel.DuelPlugin;
import me.duel.model.*;
import me.duel.util.ChatUtil;
import me.duel.util.ScoreboardUtil;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class DuelManager {

    private final DuelPlugin plugin;

    // uuid → active session
    private final Map<UUID, DuelSession> sessionByPlayer = new HashMap<>();
    // All unique sessions
    private final Set<DuelSession> sessions = new HashSet<>();
    // Pending requests: target → request
    private final Map<UUID, DuelRequest> pendingRequests = new HashMap<>();
    // Countdown tasks
    private final Map<DuelSession, BukkitTask> countdownTasks = new HashMap<>();

    public DuelManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    // ── Requests ──────────────────────────────────────────────────────────────

    public void sendRequest(Player sender, Player target, String kitName, int rounds) {
        int timeout = plugin.getConfig().getInt("duel.request-timeout", 30);

        DuelRequest req = new DuelRequest(sender.getUniqueId(), target.getUniqueId(), kitName, rounds);
        pendingRequests.put(target.getUniqueId(), req);

        String kit = kitName != null ? kitName : "DEFAULT";
        String bo = rounds == 1 ? "БО1" : "БО" + rounds + " (до " + ((rounds / 2) + 1) + " побед)";

        sender.sendMessage(ChatUtil.color("&8[&6⚔ &eDuel&8] &7Запрос отправлен игроку &e" + target.getName() + "&7. Кит: &a" + kit + "&7. Раунды: &a" + bo));

        target.sendMessage(ChatUtil.color("&8[&6⚔ &eDuel&8] &e" + sender.getName() + " &7вызывает вас на дуэль!"));
        target.sendMessage(ChatUtil.color("  &7Кит: &a" + kit + " &7| Раунды: &a" + bo));
        target.sendMessage(ChatUtil.color("  &a/duel accept &7— принять  &c/duel deny &7— отклонить"));

        // Auto-expire
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            DuelRequest current = pendingRequests.get(target.getUniqueId());
            if (current != null && current.getSender().equals(sender.getUniqueId())) {
                pendingRequests.remove(target.getUniqueId());
                sender.sendMessage(ChatUtil.color("&8[&6⚔ &eDuel&8] &cЗапрос к &e" + target.getName() + " &cистёк."));
                target.sendMessage(ChatUtil.color("&8[&6⚔ &eDuel&8] &cЗапрос на дуэль от &e" + sender.getName() + " &cистёк."));
            }
        }, timeout * 20L);
    }

    public boolean acceptRequest(Player target) {
        DuelRequest req = pendingRequests.remove(target.getUniqueId());
        if (req == null) return false;

        Player sender = Bukkit.getPlayer(req.getSender());
        if (sender == null || !sender.isOnline()) {
            target.sendMessage(ChatUtil.color("&8[&6⚔ &eDuel&8] &cИгрок вышел с сервера."));
            return false;
        }
        startDuel(sender, target, req.getKitName(), req.getRounds());
        return true;
    }

    public boolean denyRequest(Player target) {
        DuelRequest req = pendingRequests.remove(target.getUniqueId());
        if (req == null) return false;
        Player sender = Bukkit.getPlayer(req.getSender());
        target.sendMessage(ChatUtil.color("&8[&6⚔ &eDuel&8] &7Вы отклонили запрос."));
        if (sender != null) sender.sendMessage(ChatUtil.color("&8[&6⚔ &eDuel&8] &e" + target.getName() + " &7отклонил дуэль."));
        return true;
    }

    public boolean cancelRequest(Player sender) {
        Iterator<Map.Entry<UUID, DuelRequest>> it = pendingRequests.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, DuelRequest> entry = it.next();
            if (entry.getValue().getSender().equals(sender.getUniqueId())) {
                it.remove();
                Player target = Bukkit.getPlayer(entry.getKey());
                sender.sendMessage(ChatUtil.color("&8[&6⚔ &eDuel&8] &7Запрос отменён."));
                if (target != null) target.sendMessage(ChatUtil.color("&8[&6⚔ &eDuel&8] &e" + sender.getName() + " &7отменил запрос."));
                return true;
            }
        }
        return false;
    }

    public boolean hasPendingRequest(UUID uuid) { return pendingRequests.containsKey(uuid); }

    // ── Start Duel ────────────────────────────────────────────────────────────

    public void startDuel(Player p1, Player p2, String kitName, int rounds) {
        Optional<Arena> arenaOpt = plugin.getArenaManager().getFreeArena();
        if (arenaOpt.isEmpty()) {
            p1.sendMessage(ChatUtil.color("&8[&6⚔ &eDuel&8] &cНет доступных арен!"));
            p2.sendMessage(ChatUtil.color("&8[&6⚔ &eDuel&8] &cНет доступных арен!"));
            return;
        }

        Arena arena = arenaOpt.get();
        arena.setInUse(true);

        DuelSession session = new DuelSession(p1.getUniqueId(), p2.getUniqueId(), arena, kitName, rounds);

        // Save inventories and locations
        session.setSavedInventory1(p1.getInventory().getContents().clone());
        session.setSavedArmor1(p1.getInventory().getArmorContents().clone());
        session.setSavedLocation1(p1.getLocation().clone());
        session.setSavedInventory2(p2.getInventory().getContents().clone());
        session.setSavedArmor2(p2.getInventory().getArmorContents().clone());
        session.setSavedLocation2(p2.getLocation().clone());

        sessionByPlayer.put(p1.getUniqueId(), session);
        sessionByPlayer.put(p2.getUniqueId(), session);
        sessions.add(session);

        startRound(session);
    }

    private void startRound(DuelSession session) {
        Player p1 = Bukkit.getPlayer(session.getPlayer1());
        Player p2 = Bukkit.getPlayer(session.getPlayer2());
        if (p1 == null || p2 == null) {
            endDuel(session, null, "disconnect");
            return;
        }

        session.setState(DuelSession.State.COUNTDOWN);
        session.getChangedBlocks().clear();

        // Teleport
        p1.teleport(session.getArena().getSpawn1());
        p2.teleport(session.getArena().getSpawn2());

        // Give kits
        if (session.getKitName() != null) {
            plugin.getKitManager().giveKit(p1, session.getKitName());
            plugin.getKitManager().giveKit(p2, session.getKitName());
        }

        // Freeze
        p1.setWalkSpeed(0f);
        p2.setWalkSpeed(0f);

        String bo = session.getMaxRounds() == 1 ? "БО1" : "Раунд " + session.getCurrentRound() + "/" + session.getMaxRounds();
        p1.sendMessage(ChatUtil.color("&8[&6⚔ &eDuel&8] &e" + bo + " &7— приготовьтесь!"));
        p2.sendMessage(ChatUtil.color("&8[&6⚔ &eDuel&8] &e" + bo + " &7— приготовьтесь!"));

        int countdown = plugin.getConfig().getInt("duel.countdown", 5);

        BukkitTask task = new BukkitRunnable() {
            int count = countdown;

            @Override
            public void run() {
                Player pp1 = Bukkit.getPlayer(session.getPlayer1());
                Player pp2 = Bukkit.getPlayer(session.getPlayer2());
                if (pp1 == null || pp2 == null) {
                    endDuel(session, null, "disconnect");
                    cancel();
                    return;
                }
                if (count > 0) {
                    pp1.sendTitle(ChatUtil.color("&e" + count), ChatUtil.color("&7Приготовьтесь!"), 0, 25, 5);
                    pp2.sendTitle(ChatUtil.color("&e" + count), ChatUtil.color("&7Приготовьтесь!"), 0, 25, 5);
                    pp1.playSound(pp1.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1f);
                    pp2.playSound(pp2.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1f);
                    count--;
                } else {
                    // FIGHT
                    session.setState(DuelSession.State.FIGHTING);
                    session.setStartTime(System.currentTimeMillis());

                    pp1.setWalkSpeed(0.2f);
                    pp2.setWalkSpeed(0.2f);
                    pp1.sendTitle(ChatUtil.color("&a&lFIGHT!"), "", 0, 30, 10);
                    pp2.sendTitle(ChatUtil.color("&a&lFIGHT!"), "", 0, 30, 10);
                    pp1.playSound(pp1.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.2f);
                    pp2.playSound(pp2.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.2f);

                    // Start scoreboard updater
                    startScoreboard(session);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
        countdownTasks.put(session, task);
    }

    // ── Scoreboard ────────────────────────────────────────────────────────────

    private void startScoreboard(DuelSession session) {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (session.getState() == DuelSession.State.ENDED) {
                    cancel();
                    return;
                }
                Player pp1 = Bukkit.getPlayer(session.getPlayer1());
                Player pp2 = Bukkit.getPlayer(session.getPlayer2());
                if (pp1 == null || pp2 == null) { cancel(); return; }

                long elapsed = (System.currentTimeMillis() - session.getStartTime()) / 1000;
                String time = String.format("%02d:%02d", elapsed / 60, elapsed % 60);

                PlayerStats stats1 = plugin.getDatabaseManager().getStats(pp1.getUniqueId(), pp1.getName());
                PlayerStats stats2 = plugin.getDatabaseManager().getStats(pp2.getUniqueId(), pp2.getName());

                ScoreboardUtil.update(pp1, pp2.getName(), time, stats1.getElo(), session);
                ScoreboardUtil.update(pp2, pp1.getName(), time, stats2.getElo(), session);
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    // ── End Round / Duel ──────────────────────────────────────────────────────

    public void handleDeath(Player died) {
        DuelSession session = sessionByPlayer.get(died.getUniqueId());
        if (session == null || session.getState() != DuelSession.State.FIGHTING) return;

        UUID winnerId = session.getOpponent(died.getUniqueId());
        session.recordWin(winnerId);

        Player winner = Bukkit.getPlayer(winnerId);
        Player loser = died;

        // Round end messages
        broadcastToSession(session, ChatUtil.color("&8[&6⚔ &eDuel&8] &e" + (winner != null ? winner.getName() : "?")
                + " &aвыиграл раунд " + (session.getCurrentRound() - 1) + "!"));

        if (session.isMatchOver()) {
            endDuel(session, winnerId, "death");
        } else {
            // Next round after 3 seconds
            cleanArena(session);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (session.getState() != DuelSession.State.ENDED) startRound(session);
            }, 60L);
        }
    }

    public void endDuel(DuelSession session, UUID winnerId, String reason) {
        if (session.getState() == DuelSession.State.ENDED) return;
        session.setState(DuelSession.State.ENDED);

        BukkitTask ct = countdownTasks.remove(session);
        if (ct != null) ct.cancel();

        Player p1 = Bukkit.getPlayer(session.getPlayer1());
        Player p2 = Bukkit.getPlayer(session.getPlayer2());

        // Determine winner/loser
        boolean isDraw = winnerId == null && !reason.equals("disconnect");
        UUID loserId = winnerId == null ? null : session.getOpponent(winnerId);

        // ELO update
        int winElo = plugin.getConfig().getInt("duel.win-elo", 25);
        int lossElo = plugin.getConfig().getInt("duel.loss-elo", 20);

        if (!isDraw && winnerId != null) {
            Player winner = Bukkit.getPlayer(winnerId);
            Player loser = loserId != null ? Bukkit.getPlayer(loserId) : null;

            String wName = winner != null ? winner.getName() : "Unknown";
            String lName = loser != null ? loser.getName() : "Unknown";

            PlayerStats ws = plugin.getDatabaseManager().getStats(winnerId, wName);
            ws.addWin(winElo);
            plugin.getDatabaseManager().saveStats(ws);

            if (loserId != null) {
                PlayerStats ls = plugin.getDatabaseManager().getStats(loserId, lName);
                ls.addLoss(lossElo);
                plugin.getDatabaseManager().saveStats(ls);
            }

            // Show result
            sendResultMessage(p1, p2, session, winnerId, ws, loserId);

            if (winner != null) {
                winner.playSound(winner.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
                winner.sendTitle(ChatUtil.color("&a&lПОБЕДА!"), ChatUtil.color("&7+" + winElo + " ELO"), 0, 60, 20);
                spawnFirework(winner.getLocation());
            }
            if (loser != null) {
                loser.playSound(loser.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                loser.sendTitle(ChatUtil.color("&c&lПОРАЖЕНИЕ"), ChatUtil.color("&7-" + lossElo + " ELO"), 0, 60, 20);
            }
        } else {
            // Draw
            if (p1 != null) { p1.sendTitle(ChatUtil.color("&e&lНИЧЬЯ"), "", 0, 60, 20); }
            if (p2 != null) { p2.sendTitle(ChatUtil.color("&e&lНИЧЬЯ"), "", 0, 60, 20); }
        }

        // Clean arena
        cleanArena(session);

        // Kick spectators
        for (UUID specUuid : session.getSpectators()) {
            Player spec = Bukkit.getPlayer(specUuid);
            if (spec != null) plugin.getSpectatorManager().removeSpectator(spec);
        }

        // Restore and teleport after 3 sec
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            restorePlayer(p1, session.getSavedInventory1(), session.getSavedArmor1());
            restorePlayer(p2, session.getSavedInventory2(), session.getSavedArmor2());
            teleportToLobby(p1);
            teleportToLobby(p2);
            if (p1 != null) ScoreboardUtil.remove(p1);
            if (p2 != null) ScoreboardUtil.remove(p2);
        }, 60L);

        // Release arena
        session.getArena().setInUse(false);
        sessions.remove(session);
        sessionByPlayer.remove(session.getPlayer1());
        sessionByPlayer.remove(session.getPlayer2());
    }

    private void sendResultMessage(Player p1, Player p2, DuelSession session, UUID winnerId, PlayerStats ws, UUID loserId) {
        String separator = ChatUtil.color("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━");
        String winName = Bukkit.getOfflinePlayer(winnerId).getName();
        String losName = loserId != null ? Bukkit.getOfflinePlayer(loserId).getName() : "?";

        List<String> msg = List.of(
                separator,
                ChatUtil.color("       &6⚔ &e&lДУЭЛЬ ОКОНЧЕНА &6⚔"),
                separator,
                ChatUtil.color("  &7Победитель: &a" + winName),
                ChatUtil.color("  &7Счёт раундов: &e" + session.getWins(session.getPlayer1()) + " &7— &e" + session.getWins(session.getPlayer2())),
                ChatUtil.color("  &7ELO: &a" + (ws.getElo() - plugin.getConfig().getInt("duel.win-elo", 25)) + " → " + ws.getElo()),
                separator
        );

        if (p1 != null) msg.forEach(p1::sendMessage);
        if (p2 != null) msg.forEach(p2::sendMessage);
    }

    // ── Arena Cleanup ─────────────────────────────────────────────────────────

    public void cleanArena(DuelSession session) {
        // Restore blocks
        for (Map.Entry<Location, BlockState> entry : session.getChangedBlocks().entrySet()) {
            entry.getValue().update(true, false);
        }
        session.getChangedBlocks().clear();

        // Remove dropped items, arrows, XP orbs in arena
        Arena arena = session.getArena();
        if (arena.getSpawn1() == null) return;
        World world = arena.getSpawn1().getWorld();
        if (world == null) return;

        world.getEntities().stream()
                .filter(e -> e instanceof Item || e instanceof Arrow || e instanceof ExperienceOrb || e instanceof ThrownPotion)
                .filter(e -> isNearArena(e.getLocation(), arena))
                .forEach(Entity::remove);
    }

    private boolean isNearArena(Location loc, Arena arena) {
        // Simple bounding check: within 50 blocks of either spawn
        return loc.getWorld().equals(arena.getSpawn1().getWorld()) &&
                (loc.distance(arena.getSpawn1()) < 50 || loc.distance(arena.getSpawn2()) < 50);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void restorePlayer(Player player, ItemStack[] inv, ItemStack[] armor) {
        if (player == null) return;
        player.setWalkSpeed(0.2f);
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.getInventory().setContents(inv != null ? inv : new ItemStack[0]);
        player.getInventory().setArmorContents(armor != null ? armor : new ItemStack[4]);
        player.updateInventory();
    }

    private void teleportToLobby(Player player) {
        if (player == null) return;
        var cfg = plugin.getConfig();
        String worldName = cfg.getString("duel.lobby-spawn.world", "world");
        var world = plugin.getServer().getWorld(worldName);
        if (world == null) return;
        player.teleport(new Location(world,
                cfg.getDouble("duel.lobby-spawn.x"),
                cfg.getDouble("duel.lobby-spawn.y"),
                cfg.getDouble("duel.lobby-spawn.z"),
                (float) cfg.getDouble("duel.lobby-spawn.yaw"),
                (float) cfg.getDouble("duel.lobby-spawn.pitch")));
    }

    private void broadcastToSession(DuelSession session, String msg) {
        for (UUID uuid : List.of(session.getPlayer1(), session.getPlayer2())) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) p.sendMessage(msg);
        }
        session.getSpectators().forEach(uuid -> {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) p.sendMessage(msg);
        });
    }

    private void spawnFirework(Location loc) {
        org.bukkit.entity.Firework fw = loc.getWorld().spawn(loc, org.bukkit.entity.Firework.class);
        var meta = fw.getFireworkMeta();
        meta.addEffect(org.bukkit.FireworkEffect.builder()
                .with(org.bukkit.FireworkEffect.Type.STAR)
                .withColor(org.bukkit.Color.GOLD)
                .withFade(org.bukkit.Color.YELLOW)
                .withTrail().build());
        meta.setPower(1);
        fw.setFireworkMeta(meta);
    }

    public void endAllDuels() {
        new HashSet<>(sessions).forEach(s -> endDuel(s, null, "shutdown"));
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    public DuelSession getSession(UUID uuid) { return sessionByPlayer.get(uuid); }
    public boolean isInDuel(UUID uuid) { return sessionByPlayer.containsKey(uuid); }
    public Map<UUID, DuelSession> getSessionMap() { return sessionByPlayer; }
    public Set<DuelSession> getSessions() { return sessions; }
}

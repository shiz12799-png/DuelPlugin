package me.duel.spectator;

import me.duel.DuelPlugin;
import me.duel.model.DuelSession;
import me.duel.util.C;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

import java.util.*;

public class SpectatorManager {

    private final DuelPlugin plugin;
    // uuid -> session they spectate
    private final Map<UUID, DuelSession> spectating = new HashMap<>();

    public SpectatorManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isSpectating(UUID uuid) {
        return spectating.containsKey(uuid);
    }

    public DuelSession getSpectatedSession(UUID uuid) {
        return spectating.get(uuid);
    }

    public void startSpectating(Player spectator, DuelSession session) {
        spectating.put(spectator.getUniqueId(), session);
        session.getSpectators().add(spectator.getUniqueId());

        spectator.setGameMode(GameMode.SPECTATOR);
        // Teleport to arena center between the two spawns
        spectator.teleport(session.getArena().getSpawn1());
        spectator.sendMessage(C.msg("&aВы наблюдаете за дуэлью. &7/duel leave чтобы выйти."));
    }

    public void stopSpectating(Player spectator) {
        DuelSession session = spectating.remove(spectator.getUniqueId());
        if (session != null) session.getSpectators().remove(spectator.getUniqueId());

        spectator.setGameMode(GameMode.SURVIVAL);
        plugin.getDuelManager().teleportToLobby(spectator);
        spectator.sendMessage(C.msg("&eВы покинули режим наблюдателя."));
    }

    public void removeAllSpectators(DuelSession session) {
        for (UUID uid : new HashSet<>(session.getSpectators())) {
            Player p = plugin.getServer().getPlayer(uid);
            if (p != null) stopSpectating(p);
        }
    }
}

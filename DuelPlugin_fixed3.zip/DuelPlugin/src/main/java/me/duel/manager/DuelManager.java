package me.duel.manager;

import me.duel.DuelPlugin;
import me.duel.model.*;
import me.duel.util.ChatUtil;
import me.duel.util.ScoreboardUtil;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class DuelManager {

    private final DuelPlugin plugin;
    private final Map<UUID, DuelSession> sessionByPlayer = new HashMap<>();
    private final Set<DuelSession> sessions = new HashSet<>();
    private final Map<UUID, DuelRequest> pendingRequests = new HashMap<>();
    private final Map<DuelSession, BukkitTask> countdownTasks = new HashMap<>();

    public DuelManager(DuelPlugin plugin) { this.plugin = plugin; }

    public void sendRequest(Player sender, Player target, String kitName, int rounds) {
        int timeout = plugin.getConfig().getInt("duel.request-timeout", 30);
        pendingRequests.put(target.getUniqueId(), new DuelRequest(sender.getUniqueId(), target.getUniqueId(), kitName, rounds));
        String kit = kitName != null ? kitName : "DEFAULT";
        String bo = rounds == 1 ? "БО1" : "БО" + rounds;
        sender.sendMessage(ChatUtil.msg("&7Запрос отправлен &e" + target.getName() + " &7| Кит: &a" + kit + " &7| Раунды: &a" + bo));
        target.sendMessage(ChatUtil.msg("&e" + sender.getName() + " &7вызывает вас! Кит: &a" + kit + " &7| Раунды: &a" + bo));
        target.sendMessage(ChatUtil.color("  &a/duel accept &7— принять  &c/duel deny &7— отклонить"));
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            DuelRequest cur = pendingRequests.get(target.getUniqueId());
            if (cur != null && cur.getSender().equals(sender.getUniqueId())) {
                pendingRequests.remove(target.getUniqueId());
                sender.sendMessage(ChatUtil.msg("&cЗапрос истёк."));
                if (target.isOnline()) target.sendMessage(ChatUtil.msg("&cЗапрос от &e" + sender.getName() + " &cистёк."));
            }
        }, timeout * 20L);
    }

    public boolean acceptRequest(Player target) {
        DuelRequest req = pendingRequests.remove(target.getUniqueId());
        if (req == null) return false;
        Player sender = Bukkit.getPlayer(req.getSender());
        if (sender == null) { target.sendMessage(ChatUtil.msg("&cИгрок вышел.")); return false; }
        startDuel(sender, target, req.getKitName(), req.getRounds());
        return true;
    }

    public boolean denyRequest(Player target) {
        DuelRequest req = pendingRequests.remove(target.getUniqueId());
        if (req == null) return false;
        Player sender = Bukkit.getPlayer(req.getSender());
        target.sendMessage(ChatUtil.msg("&7Вы отклонили запрос."));
        if (sender != null) sender.sendMessage(ChatUtil.msg("&e" + target.getName() + " &7отклонил дуэль."));
        return true;
    }

    public boolean cancelRequest(Player sender) {
        Iterator<Map.Entry<UUID, DuelRequest>> it = pendingRequests.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, DuelRequest> e = it.next();
            if (e.getValue().getSender().equals(sender.getUniqueId())) {
                it.remove();
                Player target = Bukkit.getPlayer(e.getKey());
                sender.sendMessage(ChatUtil.msg("&7Запрос отменён."));
                if (target != null) target.sendMessage(ChatUtil.msg("&e" + sender.getName() + " &7отменил запрос."));
                return true;
            }
        }
        return false;
    }

    public boolean hasPendingRequest(UUID uuid) { return pendingRequests.containsKey(uuid); }

    public void startDuel(Player p1, Player p2, String kitName, int rounds) {
        Optional<Arena> opt = plugin.getArenaManager().getFreeArena();
        if (opt.isEmpty()) {
            p1.sendMessage(ChatUtil.msg("&cНет свободных арен!")); p2.sendMessage(ChatUtil.msg("&cНет свободных арен!")); return;
        }
        Arena arena = opt.get();
        arena.setInUse(true);
        DuelSession session = new DuelSession(p1.getUniqueId(), p2.getUniqueId(), arena, kitName, rounds);
        session.setSavedInventory1(p1.getInventory().getContents().clone());
        session.setSavedArmor1(p1.getInventory().getArmorContents().clone());
        session.setSavedLocation1(p1.getLocation().clone());
        session.setSavedInventory2(p2.getInventory().getContents().clone());
        session.setSavedArmor2(p2.getInventory().getArmorContents().clone());
        session.setSavedLocation2(p2.getLocation().clone());
        sessionByPlayer.put(p1.getUniqueId(), session);
        sessionByPlayer.put(p2.getUniqueId(), session);
        sessions.add(session);
        startRound(session);
    }

    private void startRound(DuelSession session) {
        Player p1 = Bukkit.getPlayer(session.getPlayer1());
        Player p2 = Bukkit.getPlayer(session.getPlayer2());
        if (p1 == null || p2 == null) { endDuel(session, null, "disconnect"); return; }
        session.setState(DuelSession.State.COUNTDOWN);
        session.getChangedBlocks().clear();
        p1.teleport(session.getArena().getSpawn1());
        p2.teleport(session.getArena().getSpawn2());
        if (session.getKitName() != null) {
            plugin.getKitManager().giveKit(p1, session.getKitName());
            plugin.getKitManager().giveKit(p2, session.getKitName());
        }
        p1.setWalkSpeed(0f); p2.setWalkSpeed(0f);
        String bo = session.getMaxRounds() == 1 ? "БО1" : "Раунд " + session.getCurrentRound() + "/" + session.getMaxRounds();
        p1.sendMessage(ChatUtil.msg("&e" + bo + " &7— приготовьтесь!")); p2.sendMessage(ChatUtil.msg("&e" + bo + " &7— приготовьтесь!"));
        int cd = plugin.getConfig().getInt("duel.countdown", 5);
        BukkitTask task = new BukkitRunnable() {
            int count = cd;
            @Override public void run() {
                Player pp1 = Bukkit.getPlayer(session.getPlayer1());
                Player pp2 = Bukkit.getPlayer(session.getPlayer2());
                if (pp1 == null || pp2 == null) { endDuel(session, null, "disconnect"); cancel(); return; }
                if (count > 0) {
                    pp1.sendTitle(ChatUtil.color("&e" + count), ChatUtil.color("&7Приготовьтесь!"), 0, 25, 5);
                    pp2.sendTitle(ChatUtil.color("&e" + count), ChatUtil.color("&7Приготовьтесь!"), 0, 25, 5);
                    pp1.playSound(pp1.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1f);
                    pp2.playSound(pp2.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1f);
                    count--;
                } else {
                    session.setState(DuelSession.State.FIGHTING);
                    session.setStartTime(System.currentTimeMillis());
                    pp1.setWalkSpeed(0.2f); pp2.setWalkSpeed(0.2f);
                    pp1.sendTitle(ChatUtil.color("&a&lFIGHT!"), "", 0, 30, 10);
                    pp2.sendTitle(ChatUtil.color("&a&lFIGHT!"), "", 0, 30, 10);
                    pp1.playSound(pp1.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.2f);
                    pp2.playSound(pp2.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.2f);
                    startScoreboard(session); cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
        countdownTasks.put(session, task);
    }

    private void startScoreboard(DuelSession session) {
        new BukkitRunnable() {
            @Override public void run() {
                if (session.getState() == DuelSession.State.ENDED) { cancel(); return; }
                Player pp1 = Bukkit.getPlayer(session.getPlayer1());
                Player pp2 = Bukkit.getPlayer(session.getPlayer2());
                if (pp1 == null || pp2 == null) { cancel(); return; }
                long elapsed = (System.currentTimeMillis() - session.getStartTime()) / 1000;
                String time = String.format("%02d:%02d", elapsed / 60, elapsed % 60);
                PlayerStats s1 = plugin.getDatabaseManager().getStats(pp1.getUniqueId(), pp1.getName());
                PlayerStats s2 = plugin.getDatabaseManager().getStats(pp2.getUniqueId(), pp2.getName());
                ScoreboardUtil.update(pp1, pp2.getName(), time, s1.getElo(), session);
                ScoreboardUtil.update(pp2, pp1.getName(), time, s2.getElo(), session);
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    public void handleDeath(Player died) {
        DuelSession session = sessionByPlayer.get(died.getUniqueId());
        if (session == null || session.getState() != DuelSession.State.FIGHTING) return;
        UUID winnerId = session.getOpponent(died.getUniqueId());
        session.recordWin(winnerId);
        Player winner = Bukkit.getPlayer(winnerId);
        broadcastToSession(session, ChatUtil.msg("&e" + (winner != null ? winner.getName() : "?") + " &aвыиграл раунд " + (session.getCurrentRound() - 1) + "!"));
        if (session.isMatchOver()) endDuel(session, winnerId, "death");
        else { cleanArena(session); Bukkit.getScheduler().runTaskLater(plugin, () -> { if (session.getState() != DuelSession.State.ENDED) startRound(session); }, 60L); }
    }

    public void endDuel(DuelSession session, UUID winnerId, String reason) {
        if (session.getState() == DuelSession.State.ENDED) return;
        session.setState(DuelSession.State.ENDED);
        BukkitTask ct = countdownTasks.remove(session);
        if (ct != null) ct.cancel();
        Player p1 = Bukkit.getPlayer(session.getPlayer1());
        Player p2 = Bukkit.getPlayer(session.getPlayer2());
        boolean isDraw = winnerId == null && !reason.equals("disconnect");
        UUID loserId = winnerId != null ? session.getOpponent(winnerId) : null;
        int winElo = plugin.getConfig().getInt("duel.win-elo", 25);
        int lossElo = plugin.getConfig().getInt("duel.loss-elo", 20);
        if (!isDraw && winnerId != null) {
            String wName = Optional.ofNullable(Bukkit.getOfflinePlayer(winnerId).getName()).orElse("Unknown");
            PlayerStats ws = plugin.getDatabaseManager().getStats(winnerId, wName);
            ws.addWin(winElo);
            plugin.getDatabaseManager().saveStats(ws);
            if (loserId != null) {
                String lName = Optional.ofNullable(Bukkit.getOfflinePlayer(loserId).getName()).orElse("Unknown");
                PlayerStats ls = plugin.getDatabaseManager().getStats(loserId, lName);
                ls.addLoss(lossElo);
                plugin.getDatabaseManager().saveStats(ls);
            }
            String sep = ChatUtil.color("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━");
            int oldElo = ws.getElo() - winElo;
            List<String> msg = List.of(sep, ChatUtil.color("       &6⚔ &e&lДУЭЛЬ ОКОНЧЕНА &6⚔"), sep,
                    ChatUtil.color("  &7Победитель: &a" + wName),
                    ChatUtil.color("  &7Счёт: &e" + session.getWinsPlayer1() + " &7— &e" + session.getWinsPlayer2()),
                    ChatUtil.color("  &7ELO: &a" + oldElo + " → " + ws.getElo()), sep);
            if (p1 != null) msg.forEach(p1::sendMessage);
            if (p2 != null) msg.forEach(p2::sendMessage);
            Player winner = Bukkit.getPlayer(winnerId);
            Player loser = loserId != null ? Bukkit.getPlayer(loserId) : null;
            if (winner != null) { winner.playSound(winner.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f); winner.sendTitle(ChatUtil.color("&a&lПОБЕДА!"), ChatUtil.color("&7+" + winElo + " ELO"), 0, 60, 20); spawnFirework(winner.getLocation()); }
            if (loser != null) { loser.playSound(loser.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f); loser.sendTitle(ChatUtil.color("&c&lПОРАЖЕНИЕ"), ChatUtil.color("&7-" + lossElo + " ELO"), 0, 60, 20); }
        } else {
            if (p1 != null) p1.sendTitle(ChatUtil.color("&e&lНИЧЬЯ"), "", 0, 60, 20);
            if (p2 != null) p2.sendTitle(ChatUtil.color("&e&lНИЧЬЯ"), "", 0, 60, 20);
        }
        cleanArena(session);
        new HashSet<>(session.getSpectators()).forEach(uid -> { Player sp = Bukkit.getPlayer(uid); if (sp != null) plugin.getSpectatorManager().removeSpectator(sp); });
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            restorePlayer(p1, session.getSavedInventory1(), session.getSavedArmor1());
            restorePlayer(p2, session.getSavedInventory2(), session.getSavedArmor2());
            teleportToLobby(p1); teleportToLobby(p2);
            if (p1 != null) ScoreboardUtil.remove(p1);
            if (p2 != null) ScoreboardUtil.remove(p2);
        }, 60L);
        session.getArena().setInUse(false);
        sessions.remove(session);
        sessionByPlayer.remove(session.getPlayer1());
        sessionByPlayer.remove(session.getPlayer2());
    }

    public void cleanArena(DuelSession session) {
        session.getChangedBlocks().forEach((loc, state) -> state.update(true, false));
        session.getChangedBlocks().clear();
        Arena arena = session.getArena();
        if (arena.getSpawn1() == null) return;
        World world = arena.getSpawn1().getWorld();
        if (world == null) return;
        world.getEntities().stream()
                .filter(e -> e instanceof Item || e instanceof Arrow || e instanceof ExperienceOrb || e instanceof ThrownPotion)
                .filter(e -> isNearArena(e.getLocation(), arena))
                .forEach(Entity::remove);
    }

    private boolean isNearArena(Location loc, Arena arena) {
        if (!loc.getWorld().equals(arena.getSpawn1().getWorld())) return false;
        return loc.distance(arena.getSpawn1()) < 50 || loc.distance(arena.getSpawn2()) < 50;
    }

    private void restorePlayer(Player p, ItemStack[] inv, ItemStack[] armor) {
        if (p == null) return;
        p.setWalkSpeed(0.2f); p.setHealth(p.getMaxHealth()); p.setFoodLevel(20);
        p.getInventory().setContents(inv != null ? inv : new ItemStack[0]);
        p.getInventory().setArmorContents(armor != null ? armor : new ItemStack[4]);
        p.updateInventory();
    }

    private void teleportToLobby(Player p) {
        if (p == null) return;
        var cfg = plugin.getConfig();
        World world = plugin.getServer().getWorld(cfg.getString("duel.lobby-spawn.world", "world"));
        if (world == null) return;
        p.teleport(new Location(world, cfg.getDouble("duel.lobby-spawn.x"), cfg.getDouble("duel.lobby-spawn.y"), cfg.getDouble("duel.lobby-spawn.z"), (float) cfg.getDouble("duel.lobby-spawn.yaw"), (float) cfg.getDouble("duel.lobby-spawn.pitch")));
    }

    private void broadcastToSession(DuelSession session, String msg) {
        for (UUID uid : List.of(session.getPlayer1(), session.getPlayer2())) { Player p = Bukkit.getPlayer(uid); if (p != null) p.sendMessage(msg); }
        session.getSpectators().forEach(uid -> { Player p = Bukkit.getPlayer(uid); if (p != null) p.sendMessage(msg); });
    }

    private void spawnFirework(Location loc) {
        Firework fw = loc.getWorld().spawn(loc, Firework.class);
        var meta = fw.getFireworkMeta();
        meta.addEffect(FireworkEffect.builder().with(FireworkEffect.Type.STAR).withColor(Color.fromRGB(255, 215, 0)).withFade(Color.fromRGB(255, 255, 0)).withTrail().build());
        meta.setPower(1); fw.setFireworkMeta(meta);
    }

    public void endAllDuels() { new HashSet<>(sessions).forEach(s -> endDuel(s, null, "shutdown")); }

    public DuelSession getSession(UUID uuid) { return sessionByPlayer.get(uuid); }
    public boolean isInDuel(UUID uuid) { return sessionByPlayer.containsKey(uuid); }
    public Set<DuelSession> getSessions() { return sessions; }
}

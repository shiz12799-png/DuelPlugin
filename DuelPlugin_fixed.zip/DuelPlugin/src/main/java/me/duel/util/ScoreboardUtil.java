package me.duel.util;

import me.duel.model.DuelSession;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

public class ScoreboardUtil {

    public static void update(Player player, String opponentName, String time, int elo, DuelSession session) {
        ScoreboardManager manager = Bukkit.getScoreboardManager();
        Scoreboard board = player.getScoreboard();

        Objective obj = board.getObjective("duel");
        if (obj == null) {
            board = manager.getNewScoreboard();
            obj = board.registerNewObjective("duel", Criteria.DUMMY,
                    ChatColor.GOLD + "" + ChatColor.BOLD + "⚔ ДУЭЛЬ");
            obj.setDisplaySlot(DisplaySlot.SIDEBAR);
            player.setScoreboard(board);
        } else {
            for (String entry : board.getEntries()) board.resetScores(entry);
        }

        int myWins = session.getWinsForPlayer(player.getUniqueId());
        int opWins = session.getWinsForPlayer(session.getOpponent(player.getUniqueId()));
        String bo = session.getMaxRounds() == 1 ? "БО1" :
                "Раунд " + session.getCurrentRound() + "/" + session.getMaxRounds();

        obj.getScore(ChatColor.GRAY + "─────────────").setScore(10);
        obj.getScore(ChatColor.YELLOW + "Противник: " + ChatColor.WHITE + opponentName).setScore(9);
        obj.getScore(ChatColor.YELLOW + "Время: " + ChatColor.WHITE + time).setScore(8);
        obj.getScore(ChatColor.GRAY + " ").setScore(7);
        obj.getScore(ChatColor.YELLOW + "Раунды: " + ChatColor.WHITE + bo).setScore(6);
        obj.getScore(ChatColor.GREEN + "Твои победы: " + ChatColor.WHITE + myWins).setScore(5);
        obj.getScore(ChatColor.RED + "Победы врага: " + ChatColor.WHITE + opWins).setScore(4);
        obj.getScore(ChatColor.GRAY + "  ").setScore(3);
        obj.getScore(ChatColor.YELLOW + "ELO: " + ChatColor.WHITE + elo).setScore(2);
        obj.getScore(ChatColor.GRAY + "──────────────").setScore(1);
    }

    public static void remove(Player player) {
        player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
    }
}

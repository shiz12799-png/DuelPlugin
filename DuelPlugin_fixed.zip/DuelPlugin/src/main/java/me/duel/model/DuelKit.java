package me.duel.model;

import org.bukkit.inventory.ItemStack;
import java.util.List;

public class DuelKit {
    private final String name;
    private final String display;
    private final List<ItemStack> items;
    private final ItemStack[] armor;

    public DuelKit(String name, String display, List<ItemStack> items, ItemStack[] armor) {
        this.name = name;
        this.display = display;
        this.items = items;
        this.armor = armor;
    }

    public String getName() { return name; }
    public String getDisplay() { return display; }
    public List<ItemStack> getItems() { return items; }
    public ItemStack[] getArmor() { return armor; }
}

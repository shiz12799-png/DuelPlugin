package me.duel.manager;

import me.duel.DuelPlugin;
import me.duel.model.DuelSign;
import me.duel.util.LocationUtil;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.block.Sign;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SignManager {

    private final DuelPlugin plugin;
    private final Map<String, DuelSign> signs = new ConcurrentHashMap<>();
    private File file;
    private FileConfiguration config;

    public SignManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        signs.clear();
        file = new File(plugin.getDataFolder(), "signs.yml");
        if (!file.exists()) plugin.saveResource("signs.yml", false);
        config = YamlConfiguration.loadConfiguration(file);

        List<?> list = config.getList("signs", new ArrayList<>());
        for (Object obj : list) {
            if (obj instanceof Map<?,?> map) {
                try {
                    Location loc = LocationUtil.deserialize((String) map.get("location"));
                    String kit = (String) map.get("kit");
                    int rounds = (int) map.getOrDefault("rounds", 1);
                    if (loc != null && kit != null) {
                        signs.put(locKey(loc), new DuelSign(loc, kit, rounds));
                    }
                } catch (Exception ignored) {}
            }
        }
        plugin.getLogger().info("Loaded " + signs.size() + " queue signs.");
    }

    public void save() {
        List<Map<String, Object>> list = new ArrayList<>();
        for (DuelSign sign : signs.values()) {
            list.add(Map.of(
                    "location", LocationUtil.serialize(sign.getLocation()),
                    "kit", sign.getKitName(),
                    "rounds", sign.getRounds()
            ));
        }
        config.set("signs", list);
        try { config.save(file); } catch (IOException e) { plugin.getLogger().warning("Could not save signs.yml"); }
    }

    public void registerSign(Location loc, String kit, int rounds) {
        signs.put(locKey(loc), new DuelSign(loc, kit, rounds));
        save();
        updateSignDisplay(loc, kit, rounds);
    }

    public void removeSign(Location loc) {
        signs.remove(locKey(loc));
        save();
    }

    public DuelSign getSign(Location loc) {
        return signs.get(locKey(loc));
    }

    public boolean isSign(Location loc) {
        return signs.containsKey(locKey(loc));
    }

    public void updateAllSigns() {
        for (DuelSign sign : signs.values()) {
            updateSignDisplay(sign.getLocation(), sign.getKitName(), sign.getRounds());
        }
    }

    public void updateSignDisplay(Location loc, String kit, int rounds) {
        if (loc.getBlock().getState() instanceof Sign sign) {
            String roundStr = rounds == 1 ? "БО1" : rounds == 3 ? "БО3" : "БО5";
            int queued = (int) plugin.getQueueManager().getQueue().stream()
                    .filter(e -> e.getKitName().equalsIgnoreCase(kit) && e.getRounds() == rounds)
                    .count();

            sign.setLine(0, ChatColor.GOLD + "" + ChatColor.BOLD + "⚔ DUEL QUEUE");
            sign.setLine(1, ChatColor.YELLOW + kit.toUpperCase());
            sign.setLine(2, ChatColor.WHITE + "Раунды: " + roundStr);
            sign.setLine(3, ChatColor.GREEN + "В очереди: " + queued);
            sign.update();
        }
    }

    private String locKey(Location loc) {
        return loc.getWorld().getName() + "_" + loc.getBlockX() + "_" + loc.getBlockY() + "_" + loc.getBlockZ();
    }

    public Map<String, DuelSign> getSigns() { return signs; }
}

package me.duel.util;

public class ChatUtil {
    public static String color(String msg) {
        return msg.replace("&", "§");
    }

    public static String prefix() {
        return color("&8[&6⚔ &eDuel&8] &r");
    }

    public static String msg(String text) {
        return prefix() + color(text);
    }
}

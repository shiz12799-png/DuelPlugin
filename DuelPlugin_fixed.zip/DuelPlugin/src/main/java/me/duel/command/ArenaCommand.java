package me.duel.command;

import me.duel.DuelPlugin;
import me.duel.model.Arena;
import me.duel.util.ChatUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArenaCommand implements CommandExecutor, TabCompleter {

    private final DuelPlugin plugin;

    public ArenaCommand(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Только для игроков.");
            return true;
        }

        if (!player.hasPermission("duel.admin")) {
            player.sendMessage(ChatUtil.msg("&cНет прав."));
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {

            case "create" -> {
                if (args.length < 2) { player.sendMessage(ChatUtil.msg("&cИспользование: /arena create <название>")); return true; }
                String name = args[1];
                if (plugin.getArenaManager().createArena(name)) {
                    player.sendMessage(ChatUtil.msg("&aАрена &e" + name + " &aсоздана! Установите спавны: /arena setspawn " + name + " 1/2"));
                } else {
                    player.sendMessage(ChatUtil.msg("&cАрена с таким названием уже существует."));
                }
            }

            case "delete" -> {
                if (args.length < 2) { player.sendMessage(ChatUtil.msg("&cИспользование: /arena delete <название>")); return true; }
                if (plugin.getArenaManager().deleteArena(args[1])) {
                    player.sendMessage(ChatUtil.msg("&aАрена &e" + args[1] + " &aудалена."));
                } else {
                    player.sendMessage(ChatUtil.msg("&cАрена не найдена."));
                }
            }

            case "setspawn" -> {
                if (args.length < 3) { player.sendMessage(ChatUtil.msg("&cИспользование: /arena setspawn <название> <1|2>")); return true; }
                String name = args[1];
                int num;
                try { num = Integer.parseInt(args[2]); }
                catch (NumberFormatException e) { player.sendMessage(ChatUtil.msg("&cУкажите 1 или 2.")); return true; }
                if (num != 1 && num != 2) { player.sendMessage(ChatUtil.msg("&cУкажите 1 или 2.")); return true; }

                if (plugin.getArenaManager().setSpawn(name, num, player.getLocation())) {
                    player.sendMessage(ChatUtil.msg("&aСпавн " + num + " арены &e" + name + " &aустановлен на вашей позиции."));
                } else {
                    player.sendMessage(ChatUtil.msg("&cАрена не найдена."));
                }
            }

            case "list" -> {
                var all = plugin.getArenaManager().getAll();
                String sep = ChatUtil.color("&8&m━━━━━━━━━━━━━━━━━━━━━━━");
                player.sendMessage(sep);
                player.sendMessage(ChatUtil.color("       &6⚔ Список арен (" + all.size() + ")"));
                player.sendMessage(sep);
                if (all.isEmpty()) {
                    player.sendMessage(ChatUtil.color("  &7Арен нет. Создайте: /arena create <название>"));
                } else {
                    for (Arena arena : all) {
                        String status = arena.isInUse() ? "&c[Занята]" : arena.isReady() ? "&a[Свободна]" : "&e[Не настроена]";
                        player.sendMessage(ChatUtil.color("  " + status + " &e" + arena.getName()));
                    }
                }
                player.sendMessage(sep);
            }

            default -> sendHelp(player);
        }
        return true;
    }

    private void sendHelp(Player player) {
        player.sendMessage(ChatUtil.color("&8&m━━━━━━━━━━━━━━━━━━━━━━━"));
        player.sendMessage(ChatUtil.color("      &6⚔ Arena Commands"));
        player.sendMessage(ChatUtil.color("&8&m━━━━━━━━━━━━━━━━━━━━━━━"));
        player.sendMessage(ChatUtil.color("  &e/arena create <name>"));
        player.sendMessage(ChatUtil.color("  &e/arena delete <name>"));
        player.sendMessage(ChatUtil.color("  &e/arena setspawn <name> <1|2>"));
        player.sendMessage(ChatUtil.color("  &e/arena list"));
        player.sendMessage(ChatUtil.color("&8&m━━━━━━━━━━━━━━━━━━━━━━━"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            for (String sub : Arrays.asList("create", "delete", "setspawn", "list")) {
                if (sub.startsWith(args[0].toLowerCase())) completions.add(sub);
            }
        } else if (args.length == 2 && !args[0].equalsIgnoreCase("create")) {
            plugin.getArenaManager().getAll().forEach(a -> {
                if (a.getName().toLowerCase().startsWith(args[1].toLowerCase()))
                    completions.add(a.getName());
            });
        } else if (args.length == 3 && args[0].equalsIgnoreCase("setspawn")) {
            completions.addAll(Arrays.asList("1", "2"));
        }
        return completions;
    }
}

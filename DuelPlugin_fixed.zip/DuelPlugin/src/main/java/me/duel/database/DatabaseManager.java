package me.duel.database;

import me.duel.DuelPlugin;
import me.duel.model.PlayerStats;

import java.io.File;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;

public class DatabaseManager {

    private final DuelPlugin plugin;
    private Connection connection;

    public DatabaseManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public void init() {
        try {
            File dbFile = new File(plugin.getDataFolder(), "data.db");
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());
            try (Statement st = connection.createStatement()) {
                st.execute("""
                    CREATE TABLE IF NOT EXISTS player_stats (
                        uuid TEXT PRIMARY KEY,
                        name TEXT NOT NULL,
                        elo INTEGER DEFAULT 1000,
                        wins INTEGER DEFAULT 0,
                        losses INTEGER DEFAULT 0,
                        draws INTEGER DEFAULT 0,
                        current_streak INTEGER DEFAULT 0,
                        best_streak INTEGER DEFAULT 0
                    )
                """);
            }
            plugin.getLogger().info("Database initialized.");
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "Failed to init database", e);
        }
    }

    public void close() {
        try {
            if (connection != null && !connection.isClosed()) connection.close();
        } catch (SQLException ignored) {}
    }

    public PlayerStats getStats(UUID uuid, String name) {
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT * FROM player_stats WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new PlayerStats(uuid, rs.getString("name"),
                        rs.getInt("elo"), rs.getInt("wins"), rs.getInt("losses"),
                        rs.getInt("draws"), rs.getInt("current_streak"), rs.getInt("best_streak"));
            }
        } catch (SQLException e) {
            plugin.getLogger().log(Level.WARNING, "getStats error", e);
        }
        // create new
        int startingElo = plugin.getConfig().getInt("duel.starting-elo", 1000);
        PlayerStats stats = new PlayerStats(uuid, name, startingElo, 0, 0, 0, 0, 0);
        saveStats(stats);
        return stats;
    }

    public void saveStats(PlayerStats stats) {
        try (PreparedStatement ps = connection.prepareStatement(
                "INSERT OR REPLACE INTO player_stats (uuid,name,elo,wins,losses,draws,current_streak,best_streak) VALUES (?,?,?,?,?,?,?,?)")) {
            ps.setString(1, stats.getUuid().toString());
            ps.setString(2, stats.getName());
            ps.setInt(3, stats.getElo());
            ps.setInt(4, stats.getWins());
            ps.setInt(5, stats.getLosses());
            ps.setInt(6, stats.getDraws());
            ps.setInt(7, stats.getCurrentStreak());
            ps.setInt(8, stats.getBestStreak());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().log(Level.WARNING, "saveStats error", e);
        }
    }

    public List<PlayerStats> getTopPlayers(int limit) {
        List<PlayerStats> list = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT * FROM player_stats ORDER BY elo DESC LIMIT ?")) {
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new PlayerStats(
                        UUID.fromString(rs.getString("uuid")),
                        rs.getString("name"),
                        rs.getInt("elo"), rs.getInt("wins"), rs.getInt("losses"),
                        rs.getInt("draws"), rs.getInt("current_streak"), rs.getInt("best_streak")));
            }
        } catch (SQLException e) {
            plugin.getLogger().log(Level.WARNING, "getTop error", e);
        }
        return list;
    }
}

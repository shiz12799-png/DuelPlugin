package me.duel.arena;

import me.duel.DuelPlugin;
import me.duel.model.Arena;
import me.duel.util.LocationUtil;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class ArenaManager {

    private final DuelPlugin plugin;
    private final Map<String, Arena> arenas = new LinkedHashMap<>();
    private File file;
    private FileConfiguration config;

    public ArenaManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        arenas.clear();
        file = new File(plugin.getDataFolder(), "arenas.yml");
        if (!file.exists()) plugin.saveResource("arenas.yml", false);
        config = YamlConfiguration.loadConfiguration(file);

        if (config.isConfigurationSection("arenas")) {
            for (String key : config.getConfigurationSection("arenas").getKeys(false)) {
                Arena arena = new Arena(key);
                arena.setSpawn1(LocationUtil.deserialize(config.getString("arenas." + key + ".spawn1", "")));
                arena.setSpawn2(LocationUtil.deserialize(config.getString("arenas." + key + ".spawn2", "")));
                arenas.put(key.toLowerCase(), arena);
            }
        }
        plugin.getLogger().info("Loaded " + arenas.size() + " arenas.");
    }

    public void save() {
        config.set("arenas", null);
        for (Arena arena : arenas.values()) {
            String path = "arenas." + arena.getName();
            config.set(path + ".spawn1", LocationUtil.serialize(arena.getSpawn1()));
            config.set(path + ".spawn2", LocationUtil.serialize(arena.getSpawn2()));
        }
        try { config.save(file); } catch (IOException e) { plugin.getLogger().warning("Could not save arenas.yml"); }
    }

    public Arena getArena(String name) { return arenas.get(name.toLowerCase()); }

    public Arena getFreeArena() {
        return arenas.values().stream()
                .filter(a -> a.isReady() && !a.isOccupied())
                .findFirst().orElse(null);
    }

    public void createArena(String name) {
        Arena arena = new Arena(name);
        arenas.put(name.toLowerCase(), arena);
        save();
    }

    public void deleteArena(String name) {
        arenas.remove(name.toLowerCase());
        save();
    }

    public Collection<Arena> getArenas() { return arenas.values(); }
    public boolean exists(String name) { return arenas.containsKey(name.toLowerCase()); }
}

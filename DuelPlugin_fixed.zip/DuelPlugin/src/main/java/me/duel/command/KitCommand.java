package me.duel.command;

import me.duel.DuelPlugin;
import me.duel.model.DuelKit;
import me.duel.util.ChatUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class KitCommand implements CommandExecutor, TabCompleter {

    private final DuelPlugin plugin;

    public KitCommand(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Только для игроков.");
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {

            // ── /kit create <name> ────────────────────────────────────────────
            case "create" -> {
                if (!player.hasPermission("duel.admin")) { player.sendMessage(ChatUtil.msg("&cНет прав.")); return true; }
                if (args.length < 2) { player.sendMessage(ChatUtil.msg("&cИспользование: /kit create <название>")); return true; }

                String name = args[1].toUpperCase();
                if (name.length() > 20) { player.sendMessage(ChatUtil.msg("&cНазвание слишком длинное (макс 20 символов).")); return true; }

                boolean empty = true;
                for (ItemStack item : player.getInventory().getContents()) {
                    if (item != null && !item.getType().isAir()) { empty = false; break; }
                }
                for (ItemStack piece : player.getInventory().getArmorContents()) {
                    if (piece != null && !piece.getType().isAir()) { empty = false; break; }
                }
                if (empty) { player.sendMessage(ChatUtil.msg("&cИнвентарь пуст! Положите предметы и/или наденьте броню.")); return true; }

                plugin.getKitManager().createKit(name, player);
                player.sendMessage(ChatUtil.msg("&aКит &e" + name + " &aсоздан из вашего инвентаря!"));
                player.sendMessage(ChatUtil.msg("&7Теперь можно использовать на табличке: &e[DuelQueue] / " + name));
            }

            // ── /kit delete <name> ────────────────────────────────────────────
            case "delete" -> {
                if (!player.hasPermission("duel.admin")) { player.sendMessage(ChatUtil.msg("&cНет прав.")); return true; }
                if (args.length < 2) { player.sendMessage(ChatUtil.msg("&cИспользование: /kit delete <название>")); return true; }
                if (plugin.getKitManager().deleteKit(args[1])) {
                    player.sendMessage(ChatUtil.msg("&aКит &e" + args[1].toUpperCase() + " &aудалён."));
                } else {
                    player.sendMessage(ChatUtil.msg("&cКит не найден."));
                }
            }

            // ── /kit list ─────────────────────────────────────────────────────
            case "list" -> {
                var kits = plugin.getKitManager().getAll();
                String sep = ChatUtil.color("&8&m━━━━━━━━━━━━━━━━━━━━━━━");
                player.sendMessage(sep);
                player.sendMessage(ChatUtil.color("       &6⚔ Список китов (" + kits.size() + ")"));
                player.sendMessage(sep);
                if (kits.isEmpty()) {
                    player.sendMessage(ChatUtil.color("  &7Китов нет. Создайте: /kit create <название>"));
                } else {
                    for (DuelKit kit : kits) {
                        player.sendMessage(ChatUtil.color("  &e" + kit.getName() + " &8— &7" + kit.getDisplay()
                                + " &8(&7предметов: &a" + kit.getItems().size() + "&8)"));
                    }
                }
                player.sendMessage(sep);
            }

            // ── /kit info <name> ──────────────────────────────────────────────
            case "info" -> {
                if (args.length < 2) { player.sendMessage(ChatUtil.msg("&cИспользование: /kit info <название>")); return true; }
                DuelKit kit = plugin.getKitManager().getKit(args[1]);
                if (kit == null) { player.sendMessage(ChatUtil.msg("&cКит не найден.")); return true; }

                String sep = ChatUtil.color("&8&m━━━━━━━━━━━━━━━━━━━━━━━");
                player.sendMessage(sep);
                player.sendMessage(ChatUtil.color("    &6⚔ Кит: &e" + kit.getName()));
                player.sendMessage(sep);
                player.sendMessage(ChatUtil.color("  &7Предметы:"));
                for (ItemStack item : kit.getItems()) {
                    player.sendMessage(ChatUtil.color("    &8• &e" + item.getType().name() + " &8x&7" + item.getAmount()));
                }
                if (kit.getArmor() != null) {
                    player.sendMessage(ChatUtil.color("  &7Броня:"));
                    String[] slotNames = {"Ботинки", "Поножи", "Нагрудник", "Шлем"};
                    for (int i = 3; i >= 0; i--) {
                        if (kit.getArmor()[i] != null) {
                            player.sendMessage(ChatUtil.color("    &8• &e" + slotNames[i] + ": &7" + kit.getArmor()[i].getType().name()));
                        }
                    }
                }
                player.sendMessage(sep);
            }

            // ── /kit give <player> <kit> ──────────────────────────────────────
            case "give" -> {
                if (!player.hasPermission("duel.admin")) { player.sendMessage(ChatUtil.msg("&cНет прав.")); return true; }
                if (args.length < 3) { player.sendMessage(ChatUtil.msg("&cИспользование: /kit give <игрок> <кит>")); return true; }

                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) { player.sendMessage(ChatUtil.msg("&cИгрок не найден.")); return true; }
                if (!plugin.getKitManager().kitExists(args[2])) { player.sendMessage(ChatUtil.msg("&cКит не найден.")); return true; }

                plugin.getKitManager().giveKit(target, args[2]);
                player.sendMessage(ChatUtil.msg("&aВыдан кит &e" + args[2].toUpperCase() + " &aигроку &e" + target.getName()));
                target.sendMessage(ChatUtil.msg("&aВам выдан кит &e" + args[2].toUpperCase()));
            }

            default -> sendHelp(player);
        }
        return true;
    }

    private void sendHelp(Player player) {
        player.sendMessage(ChatUtil.color("&8&m━━━━━━━━━━━━━━━━━━━━━━━"));
        player.sendMessage(ChatUtil.color("       &6⚔ Kit Commands"));
        player.sendMessage(ChatUtil.color("&8&m━━━━━━━━━━━━━━━━━━━━━━━"));
        player.sendMessage(ChatUtil.color("  &e/kit list &8— &7все киты"));
        player.sendMessage(ChatUtil.color("  &e/kit info <кит> &8— &7содержимое"));
        if (player.hasPermission("duel.admin")) {
            player.sendMessage(ChatUtil.color("  &e/kit create <название> &8— &7из инвентаря"));
            player.sendMessage(ChatUtil.color("  &e/kit delete <название> &8— &7удалить"));
            player.sendMessage(ChatUtil.color("  &e/kit give <игрок> <кит> &8— &7выдать"));
        }
        player.sendMessage(ChatUtil.color("&8&m━━━━━━━━━━━━━━━━━━━━━━━"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            for (String sub : Arrays.asList("create", "delete", "list", "info", "give")) {
                if (sub.startsWith(args[0].toLowerCase())) completions.add(sub);
            }
        } else if (args.length == 2) {
            switch (args[0].toLowerCase()) {
                case "delete", "info" -> plugin.getKitManager().getKitNames().forEach(k -> {
                    if (k.toLowerCase().startsWith(args[1].toLowerCase())) completions.add(k);
                });
                case "give" -> Bukkit.getOnlinePlayers().forEach(p -> {
                    if (p.getName().toLowerCase().startsWith(args[1].toLowerCase())) completions.add(p.getName());
                });
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            plugin.getKitManager().getKitNames().forEach(k -> {
                if (k.toLowerCase().startsWith(args[2].toLowerCase())) completions.add(k);
            });
        }
        return completions;
    }
}

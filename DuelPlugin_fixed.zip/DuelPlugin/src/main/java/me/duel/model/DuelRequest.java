package me.duel.model;

import org.bukkit.entity.Player;
import java.util.UUID;

public class DuelRequest {
    private final UUID sender;
    private final UUID target;
    private final String kitName;
    private final int rounds;
    private final long createdAt;

    public DuelRequest(UUID sender, UUID target, String kitName, int rounds) {
        this.sender = sender;
        this.target = target;
        this.kitName = kitName;
        this.rounds = rounds;
        this.createdAt = System.currentTimeMillis();
    }

    public boolean isExpired(int timeoutSeconds) {
        return System.currentTimeMillis() - createdAt > timeoutSeconds * 1000L;
    }

    public UUID getSender() { return sender; }
    public UUID getTarget() { return target; }
    public String getKitName() { return kitName; }
    public int getRounds() { return rounds; }
}

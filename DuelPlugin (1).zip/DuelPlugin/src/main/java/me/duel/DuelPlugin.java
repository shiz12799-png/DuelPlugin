package me.duel;

import me.duel.arena.ArenaManager;
import me.duel.command.ArenaCommand;
import me.duel.command.DuelCommand;
import me.duel.command.DuelPluginCommand;
import me.duel.command.KitCommand;
import me.duel.database.DatabaseManager;
import me.duel.kit.KitManager;
import me.duel.listener.DuelListener;
import me.duel.listener.SignListener;
import me.duel.listener.SpectatorListener;
import me.duel.manager.DuelManager;
import me.duel.manager.QueueManager;
import me.duel.manager.SignManager;
import me.duel.spectator.SpectatorManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class DuelPlugin extends JavaPlugin {

    private static DuelPlugin instance;
    private DatabaseManager databaseManager;
    private ArenaManager arenaManager;
    private KitManager kitManager;
    private DuelManager duelManager;
    private QueueManager queueManager;
    private SpectatorManager spectatorManager;
    private SignManager signManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.databaseManager = new DatabaseManager(this);
        this.databaseManager.init();
        this.arenaManager = new ArenaManager(this);
        this.kitManager = new KitManager(this);
        this.spectatorManager = new SpectatorManager(this);
        this.duelManager = new DuelManager(this);
        this.queueManager = new QueueManager(this);
        this.signManager = new SignManager(this);

        this.arenaManager.load();
        this.kitManager.load();
        this.signManager.load();

        getCommand("duel").setExecutor(new DuelCommand(this));
        getCommand("arena").setExecutor(new ArenaCommand(this));
        getCommand("kit").setExecutor(new KitCommand(this));
        getCommand("duelplugin").setExecutor(new DuelPluginCommand(this));

        getServer().getPluginManager().registerEvents(new DuelListener(this), this);
        getServer().getPluginManager().registerEvents(new SpectatorListener(this), this);
        getServer().getPluginManager().registerEvents(new SignListener(this), this);

        this.queueManager.startMatchmaking();
        getLogger().info("DuelPlugin enabled!");
    }

    @Override
    public void onDisable() {
        if (duelManager != null) duelManager.endAllDuels();
        if (databaseManager != null) databaseManager.close();
        if (signManager != null) signManager.save();
        getLogger().info("DuelPlugin disabled!");
    }

    public void reload() {
        reloadConfig();
        arenaManager.load();
        kitManager.load();
        signManager.load();
    }

    public static DuelPlugin getInstance() { return instance; }
    public DatabaseManager getDatabaseManager() { return databaseManager; }
    public ArenaManager getArenaManager() { return arenaManager; }
    public KitManager getKitManager() { return kitManager; }
    public DuelManager getDuelManager() { return duelManager; }
    public QueueManager getQueueManager() { return queueManager; }
    public SpectatorManager getSpectatorManager() { return spectatorManager; }
    public SignManager getSignManager() { return signManager; }
}

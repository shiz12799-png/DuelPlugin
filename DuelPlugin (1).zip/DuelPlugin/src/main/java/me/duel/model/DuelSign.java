package me.duel.model;

import org.bukkit.Location;

public class DuelSign {
    private final Location location;
    private final String kitName;
    private final int rounds;

    public DuelSign(Location location, String kitName, int rounds) {
        this.location = location;
        this.kitName = kitName;
        this.rounds = rounds;
    }

    public Location getLocation() { return location; }
    public String getKitName() { return kitName; }
    public int getRounds() { return rounds; }
}

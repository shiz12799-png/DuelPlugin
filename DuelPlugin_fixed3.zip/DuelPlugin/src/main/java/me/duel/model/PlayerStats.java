package me.duel.model;

import java.util.UUID;

public class PlayerStats {
    private final UUID uuid;
    private final String name;
    private int elo;
    private int wins;
    private int losses;
    private int draws;
    private int currentStreak;
    private int bestStreak;

    public PlayerStats(UUID uuid, String name, int elo, int wins, int losses, int draws, int currentStreak, int bestStreak) {
        this.uuid = uuid; this.name = name; this.elo = elo;
        this.wins = wins; this.losses = losses; this.draws = draws;
        this.currentStreak = currentStreak; this.bestStreak = bestStreak;
    }

    public double getWinRate() {
        int total = wins + losses + draws;
        return total == 0 ? 0 : (wins * 100.0) / total;
    }

    public void addWin(int eloGain) {
        wins++; elo = Math.max(100, elo + eloGain);
        currentStreak++;
        if (currentStreak > bestStreak) bestStreak = currentStreak;
    }

    public void addLoss(int eloLoss) {
        losses++; elo = Math.max(100, elo - eloLoss); currentStreak = 0;
    }

    public void addDraw() { draws++; currentStreak = 0; }

    public UUID getUuid() { return uuid; }
    public String getName() { return name; }
    public int getElo() { return elo; }
    public int getWins() { return wins; }
    public int getLosses() { return losses; }
    public int getDraws() { return draws; }
    public int getCurrentStreak() { return currentStreak; }
    public int getBestStreak() { return bestStreak; }
}

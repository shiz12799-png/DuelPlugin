package me.duel.listener;

import me.duel.DuelPlugin;
import me.duel.model.DuelSession;
import me.duel.util.ChatUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class DuelListener implements Listener {

    private final DuelPlugin plugin;

    public DuelListener(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        DuelSession session = plugin.getDuelManager().getSession(player.getUniqueId());
        if (session == null) return;

        event.setDeathMessage(null);
        event.getDrops().clear();
        event.setDroppedExp(0);
        event.setKeepInventory(true);

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (player.isDead()) player.spigot().respawn();
        }, 1L);

        plugin.getDuelManager().handleDeath(player);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();

        if (plugin.getQueueManager().isInQueue(player.getUniqueId())) {
            plugin.getQueueManager().leaveQueue(player);
        }

        if (plugin.getSpectatorManager().isSpectating(player.getUniqueId())) {
            plugin.getSpectatorManager().removeSpectator(player);
        }

        DuelSession session = plugin.getDuelManager().getSession(player.getUniqueId());
        if (session != null) {
            UUID opponentId = session.getOpponent(player.getUniqueId());
            Player opponent = plugin.getServer().getPlayer(opponentId);
            plugin.getDuelManager().endDuel(session, opponentId, "disconnect");
            if (opponent != null)
                opponent.sendMessage(ChatUtil.msg("&e" + player.getName() + " &7вышел — вы победили!"));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        DuelSession session = plugin.getDuelManager().getSession(player.getUniqueId());
        if (session == null || session.getState() != DuelSession.State.FIGHTING) return;
        session.trackBlock(event.getBlock().getLocation(), event.getBlock().getState());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        DuelSession session = plugin.getDuelManager().getSession(player.getUniqueId());
        if (session == null || session.getState() != DuelSession.State.FIGHTING) return;
        session.trackBlock(event.getBlock().getLocation(), event.getBlockReplacedState());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof Player victim)) return;

        DuelSession session = plugin.getDuelManager().getSession(attacker.getUniqueId());
        if (session == null) return;

        if (session.getState() == DuelSession.State.COUNTDOWN) {
            event.setCancelled(true);
            return;
        }

        if (!session.isParticipant(victim.getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        DuelSession session = plugin.getDuelManager().getSession(player.getUniqueId());
        if (session == null || session.getState() != DuelSession.State.COUNTDOWN) return;

        if (event.getFrom().getBlockX() != event.getTo().getBlockX()
                || event.getFrom().getBlockY() != event.getTo().getBlockY()
                || event.getFrom().getBlockZ() != event.getTo().getBlockZ()) {
            event.setTo(event.getFrom());
        }
    }
}

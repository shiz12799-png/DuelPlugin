package me.duel.model;

import java.util.UUID;

public class QueueEntry {
    private final UUID playerUUID;
    private final String kitName;
    private final int rounds;
    private final int elo;
    private final long joinedAt;

    public QueueEntry(UUID playerUUID, String kitName, int rounds, int elo) {
        this.playerUUID = playerUUID;
        this.kitName = kitName;
        this.rounds = rounds;
        this.elo = elo;
        this.joinedAt = System.currentTimeMillis();
    }

    public UUID getPlayerUUID() { return playerUUID; }
    public String getKitName() { return kitName; }
    public int getRounds() { return rounds; }
    public int getElo() { return elo; }
    public long getJoinedAt() { return joinedAt; }
}

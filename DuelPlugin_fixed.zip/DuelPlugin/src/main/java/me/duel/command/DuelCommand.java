package me.duel.command;

import me.duel.DuelPlugin;
import me.duel.model.DuelSession;
import me.duel.model.PlayerStats;
import me.duel.util.ChatUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DuelCommand implements CommandExecutor, TabCompleter {

    private final DuelPlugin plugin;

    public DuelCommand(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Только для игроков.");
            return true;
        }

        if (!player.hasPermission("duel.use")) {
            player.sendMessage(ChatUtil.msg("&cНет прав."));
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {

            // ── /duel <player> [rounds] ───────────────────────────────────────
            case "accept" -> {
                if (plugin.getDuelManager().isInDuel(player.getUniqueId())) {
                    player.sendMessage(ChatUtil.msg("&cВы уже в дуэли!"));
                    return true;
                }
                if (!plugin.getDuelManager().hasPendingRequest(player.getUniqueId())) {
                    player.sendMessage(ChatUtil.msg("&cУ вас нет запросов на дуэль."));
                    return true;
                }
                plugin.getDuelManager().acceptRequest(player);
            }

            case "deny" -> {
                if (!plugin.getDuelManager().denyRequest(player)) {
                    player.sendMessage(ChatUtil.msg("&cУ вас нет запросов на дуэль."));
                }
            }

            case "cancel" -> {
                if (plugin.getDuelManager().isInDuel(player.getUniqueId())) {
                    DuelSession session = plugin.getDuelManager().getSession(player.getUniqueId());
                    plugin.getDuelManager().endDuel(session, session.getOpponent(player.getUniqueId()), "cancel");
                    player.sendMessage(ChatUtil.msg("&7Вы отменили дуэль (засчитано поражение)."));
                } else if (!plugin.getDuelManager().cancelRequest(player)) {
                    player.sendMessage(ChatUtil.msg("&cНечего отменять."));
                }
            }

            case "queue" -> {
                if (plugin.getDuelManager().isInDuel(player.getUniqueId())) {
                    player.sendMessage(ChatUtil.msg("&cВы уже в дуэли!"));
                    return true;
                }
                if (plugin.getQueueManager().isInQueue(player.getUniqueId())) {
                    player.sendMessage(ChatUtil.msg("&cВы уже в очереди! /duel leave чтобы выйти."));
                    return true;
                }

                String kitName = args.length >= 2 ? args[1].toUpperCase() : null;
                int rounds = 1;
                if (args.length >= 3) {
                    try {
                        rounds = Integer.parseInt(args[2]);
                        if (rounds < 1) rounds = 1;
                        if (rounds % 2 == 0) rounds++;
                        if (rounds > 5) rounds = 5;
                    } catch (NumberFormatException e) {
                        player.sendMessage(ChatUtil.msg("&cНеверное количество раундов."));
                        return true;
                    }
                }

                if (kitName != null && !plugin.getKitManager().kitExists(kitName)) {
                    player.sendMessage(ChatUtil.msg("&cКит &e" + kitName + " &cне существует. /kit list"));
                    return true;
                }

                boolean joined = plugin.getQueueManager().joinQueue(player, kitName, rounds);
                if (joined) {
                    String kit = kitName != null ? kitName : "DEFAULT";
                    String bo = rounds == 1 ? "БО1" : "БО" + rounds;
                    player.sendMessage(ChatUtil.msg("&aВы в очереди! Кит: &e" + kit + " &a| Раунды: &e" + bo));
                } else {
                    player.sendMessage(ChatUtil.msg("&cНе удалось войти в очередь."));
                }
            }

            case "leave" -> {
                if (!plugin.getQueueManager().leaveQueue(player)) {
                    player.sendMessage(ChatUtil.msg("&cВы не в очереди."));
                } else {
                    player.sendMessage(ChatUtil.msg("&7Вы покинули очередь."));
                }
            }

            case "spectate" -> {
                if (args.length < 2) {
                    player.sendMessage(ChatUtil.msg("&cИспользование: /duel spectate <игрок>"));
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    player.sendMessage(ChatUtil.msg("&cИгрок не найден."));
                    return true;
                }
                if (!plugin.getDuelManager().isInDuel(target.getUniqueId())) {
                    player.sendMessage(ChatUtil.msg("&cЭтот игрок не в дуэли."));
                    return true;
                }
                if (plugin.getDuelManager().isInDuel(player.getUniqueId())) {
                    player.sendMessage(ChatUtil.msg("&cВы сами в дуэли!"));
                    return true;
                }
                boolean ok = plugin.getSpectatorManager().addSpectator(player, target);
                if (!ok) player.sendMessage(ChatUtil.msg("&cНе удалось подключиться как наблюдатель."));
            }

            case "stats" -> {
                Player target = args.length >= 2 ? Bukkit.getPlayer(args[1]) : player;
                if (target == null) {
                    player.sendMessage(ChatUtil.msg("&cИгрок не найден."));
                    return true;
                }
                showStats(player, target);
            }

            case "top" -> showTop(player);

            default -> {
                // /duel <player> [rounds]
                String targetName = args[0];
                Player target = Bukkit.getPlayer(targetName);
                if (target == null) {
                    player.sendMessage(ChatUtil.msg("&cИгрок &e" + targetName + " &cне найден."));
                    return true;
                }
                if (target.equals(player)) {
                    player.sendMessage(ChatUtil.msg("&cНельзя вызвать самого себя!"));
                    return true;
                }
                if (plugin.getDuelManager().isInDuel(player.getUniqueId())) {
                    player.sendMessage(ChatUtil.msg("&cВы уже в дуэли!"));
                    return true;
                }
                if (plugin.getDuelManager().isInDuel(target.getUniqueId())) {
                    player.sendMessage(ChatUtil.msg("&e" + target.getName() + " &cуже в дуэли."));
                    return true;
                }
                if (plugin.getDuelManager().hasPendingRequest(target.getUniqueId())) {
                    player.sendMessage(ChatUtil.msg("&cУ этого игрока уже есть входящий запрос."));
                    return true;
                }

                int rounds = 1;
                if (args.length >= 2) {
                    try {
                        rounds = Integer.parseInt(args[1]);
                        if (rounds < 1) rounds = 1;
                        if (rounds % 2 == 0) rounds++;
                        if (rounds > 5) rounds = 5;
                    } catch (NumberFormatException ignored) {
                        // treat as kit name
                    }
                }

                plugin.getDuelManager().sendRequest(player, target, null, rounds);
            }
        }
        return true;
    }

    private void showStats(Player viewer, Player target) {
        PlayerStats stats = plugin.getDatabaseManager().getStats(target.getUniqueId(), target.getName());
        int total = stats.getWins() + stats.getLosses() + stats.getDraws();
        String winRate = total == 0 ? "0%" : String.format("%.1f%%", stats.getWinRate());

        String sep = ChatUtil.color("&8&m━━━━━━━━━━━━━━━━━━━━━━━");
        viewer.sendMessage(sep);
        viewer.sendMessage(ChatUtil.color("     &6📊 Статистика: &e" + target.getName()));
        viewer.sendMessage(sep);
        viewer.sendMessage(ChatUtil.color("  &7ELO:           &e" + stats.getElo()));
        viewer.sendMessage(ChatUtil.color("  &7Победы:        &a" + stats.getWins()));
        viewer.sendMessage(ChatUtil.color("  &7Поражения:     &c" + stats.getLosses()));
        viewer.sendMessage(ChatUtil.color("  &7Ничьи:         &7" + stats.getDraws()));
        viewer.sendMessage(ChatUtil.color("  &7Винрейт:       &b" + winRate));
        viewer.sendMessage(ChatUtil.color("  &7Текущий стрик: &6" + stats.getCurrentStreak()));
        viewer.sendMessage(ChatUtil.color("  &7Лучший стрик:  &6" + stats.getBestStreak()));
        viewer.sendMessage(sep);
    }

    private void showTop(Player player) {
        List<PlayerStats> top = plugin.getDatabaseManager().getTopPlayers(10);
        String sep = ChatUtil.color("&8&m━━━━━━━━━━━━━━━━━━━━━━━");
        player.sendMessage(sep);
        player.sendMessage(ChatUtil.color("       &6🏆 Топ-10 игроков"));
        player.sendMessage(sep);
        if (top.isEmpty()) {
            player.sendMessage(ChatUtil.color("  &7Нет данных."));
        } else {
            String[] medals = {"&6#1", "&7#2", "&c#3"};
            for (int i = 0; i < top.size(); i++) {
                PlayerStats s = top.get(i);
                String rank = i < 3 ? ChatUtil.color(medals[i]) : ChatUtil.color("&8#" + (i + 1));
                player.sendMessage(ChatUtil.color("  " + rank + " &e" + s.getName()
                        + " &8— &7ELO: &a" + s.getElo()
                        + " &8| &7W: &a" + s.getWins()
                        + " &8| &7L: &c" + s.getLosses()));
            }
        }
        player.sendMessage(sep);
    }

    private void sendHelp(Player player) {
        String sep = ChatUtil.color("&8&m━━━━━━━━━━━━━━━━━━━━━━━");
        player.sendMessage(sep);
        player.sendMessage(ChatUtil.color("        &6⚔ &eDuelPlugin &6⚔"));
        player.sendMessage(sep);
        player.sendMessage(ChatUtil.color("  &e/duel <игрок> [раунды] &8— &7вызвать"));
        player.sendMessage(ChatUtil.color("  &e/duel accept &8— &7принять вызов"));
        player.sendMessage(ChatUtil.color("  &e/duel deny &8— &7отклонить вызов"));
        player.sendMessage(ChatUtil.color("  &e/duel cancel &8— &7отменить"));
        player.sendMessage(ChatUtil.color("  &e/duel queue [кит] [раунды] &8— &7очередь"));
        player.sendMessage(ChatUtil.color("  &e/duel leave &8— &7выйти из очереди"));
        player.sendMessage(ChatUtil.color("  &e/duel spectate <игрок> &8— &7наблюдать"));
        player.sendMessage(ChatUtil.color("  &e/duel stats [игрок] &8— &7статистика"));
        player.sendMessage(ChatUtil.color("  &e/duel top &8— &7топ-10 игроков"));
        player.sendMessage(sep);
        player.sendMessage(ChatUtil.color("  &e/kit list &8— &7список китов"));
        player.sendMessage(ChatUtil.color("  &e/arena list &8— &7список арен"));
        player.sendMessage(sep);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            List<String> subs = Arrays.asList("accept", "deny", "cancel", "queue", "leave", "spectate", "stats", "top");
            for (String sub : subs) {
                if (sub.startsWith(args[0].toLowerCase())) completions.add(sub);
            }
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase().startsWith(args[0].toLowerCase()))
                    completions.add(p.getName());
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("spectate")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase().startsWith(args[1].toLowerCase()))
                    completions.add(p.getName());
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("queue")) {
            plugin.getKitManager().getKitNames().forEach(k -> {
                if (k.toLowerCase().startsWith(args[1].toLowerCase())) completions.add(k);
            });
        } else if (args.length == 2 && args[0].equalsIgnoreCase("stats")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase().startsWith(args[1].toLowerCase()))
                    completions.add(p.getName());
            }
        }
        return completions;
    }
}

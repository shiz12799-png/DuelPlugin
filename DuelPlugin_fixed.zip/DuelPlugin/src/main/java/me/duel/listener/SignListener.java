package me.duel.listener;

import me.duel.DuelPlugin;
import me.duel.manager.SignQueueManager;
import me.duel.util.ChatUtil;
import org.bukkit.ChatColor;
import org.bukkit.block.Sign;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class SignListener implements Listener {

    private final DuelPlugin plugin;

    public SignListener(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onSignChange(SignChangeEvent event) {
        String line0 = ChatColor.stripColor(event.getLine(0));
        if (line0 == null || !line0.trim().equalsIgnoreCase("[DuelQueue]")) return;

        Player player = event.getPlayer();
        if (!player.hasPermission("duel.admin")) {
            player.sendMessage(ChatUtil.msg("&cНет прав для создания таблички очереди."));
            event.setCancelled(true);
            return;
        }

        String line1 = event.getLine(1);
        String kitName = (line1 != null && !line1.trim().isEmpty()) ? line1.trim().toUpperCase() : null;

        if (kitName != null && !plugin.getKitManager().kitExists(kitName)) {
            player.sendMessage(ChatUtil.msg("&cКит &e" + kitName + " &cне существует! Создайте: /kit create " + kitName));
            event.setCancelled(true);
            return;
        }

        String line2 = event.getLine(2);
        int rounds = 1;
        if (line2 != null && !line2.trim().isEmpty()) {
            try {
                rounds = Integer.parseInt(line2.trim());
                if (rounds < 1) rounds = 1;
                if (rounds % 2 == 0) rounds++;
                if (rounds > 5) rounds = 5;
            } catch (NumberFormatException ignored) {}
        }

        String bo = rounds == 1 ? "БО1" : "БО" + rounds;
        String kit = kitName != null ? kitName : "DEFAULT";

        event.setLine(0, ChatColor.GOLD + "" + ChatColor.BOLD + "⚔ DUEL QUEUE");
        event.setLine(1, ChatColor.YELLOW + kit);
        event.setLine(2, ChatColor.GRAY + "Раунды: " + ChatColor.WHITE + bo);
        event.setLine(3, ChatColor.GREEN + "В очереди: " + ChatColor.WHITE + "0");

        final String finalKit = kitName;
        final int finalRounds = rounds;

        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
                plugin.getSignQueueManager().registerSign(event.getBlock().getLocation(), finalKit, finalRounds), 1L);

        player.sendMessage(ChatUtil.msg("&aТабличка создана! Кит: &e" + kit + " &a| Раунды: &e" + bo));
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK && event.getAction() != Action.LEFT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null) return;
        if (!(event.getClickedBlock().getState() instanceof Sign)) return;

        var loc = event.getClickedBlock().getLocation();
        if (!plugin.getSignQueueManager().isQueueSign(loc)) return;

        event.setCancelled(true);
        Player player = event.getPlayer();
        SignQueueManager.SignData data = plugin.getSignQueueManager().getSignData(loc);

        if (plugin.getDuelManager().isInDuel(player.getUniqueId())) {
            player.sendMessage(ChatUtil.msg("&cВы уже в дуэли!"));
            return;
        }

        if (plugin.getQueueManager().isInQueue(player.getUniqueId())) {
            plugin.getQueueManager().leaveQueue(player);
            player.sendMessage(ChatUtil.msg("&7Вы покинули очередь."));
            return;
        }

        String kitName = data.kitName();
        int rounds = data.rounds();

        if (kitName != null && !plugin.getKitManager().kitExists(kitName)) {
            player.sendMessage(ChatUtil.msg("&cКит &e" + kitName + " &cбольше не существует!"));
            return;
        }

        boolean joined = plugin.getQueueManager().joinQueue(player, kitName, rounds);
        if (joined) {
            String kit = kitName != null ? kitName : "DEFAULT";
            String bo = rounds == 1 ? "БО1" : "БО" + rounds;
            player.sendMessage(ChatUtil.msg("&aВы в очереди! Кит: &e" + kit + " &a| Раунды: &e" + bo + " &7(нажмите снова чтобы выйти)"));
            player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
        } else {
            player.sendMessage(ChatUtil.msg("&cНе удалось войти в очередь."));
        }
    }

    @EventHandler
    public void onBreak(BlockBreakEvent event) {
        if (!(event.getBlock().getState() instanceof Sign)) return;
        var loc = event.getBlock().getLocation();
        if (!plugin.getSignQueueManager().isQueueSign(loc)) return;

        if (!event.getPlayer().hasPermission("duel.admin")) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(ChatUtil.msg("&cНет прав для удаления этой таблички!"));
            return;
        }
        plugin.getSignQueueManager().removeSign(loc);
        event.getPlayer().sendMessage(ChatUtil.msg("&7Табличка очереди удалена."));
    }
}

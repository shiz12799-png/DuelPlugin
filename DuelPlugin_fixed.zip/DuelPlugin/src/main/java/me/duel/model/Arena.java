package me.duel.model;

import org.bukkit.Location;

public class Arena {
    private final String name;
    private Location spawn1;
    private Location spawn2;
    private boolean occupied;

    public Arena(String name) {
        this.name = name;
        this.occupied = false;
    }

    public boolean isReady() {
        return spawn1 != null && spawn2 != null;
    }

    public boolean contains(Location loc) {
        if (spawn1 == null || spawn2 == null) return false;
        if (!loc.getWorld().equals(spawn1.getWorld())) return false;
        double minX = Math.min(spawn1.getX(), spawn2.getX()) - 50;
        double maxX = Math.max(spawn1.getX(), spawn2.getX()) + 50;
        double minZ = Math.min(spawn1.getZ(), spawn2.getZ()) - 50;
        double maxZ = Math.max(spawn1.getZ(), spawn2.getZ()) + 50;
        return loc.getX() >= minX && loc.getX() <= maxX
                && loc.getZ() >= minZ && loc.getZ() <= maxZ;
    }

    public String getName() { return name; }
    public Location getSpawn1() { return spawn1; }
    public void setSpawn1(Location spawn1) { this.spawn1 = spawn1; }
    public Location getSpawn2() { return spawn2; }
    public void setSpawn2(Location spawn2) { this.spawn2 = spawn2; }
    public boolean isOccupied() { return occupied; }
    public void setOccupied(boolean occupied) { this.occupied = occupied; }
}
